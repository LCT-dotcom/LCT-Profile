"""Offline tests for dedupe / ranking / parsing / report / brain (no network)."""

import sys
import xml.etree.ElementTree as ET
from datetime import date, timedelta
from pathlib import Path
from uuid import uuid4

TEST_ROOT = Path(__file__).resolve().parent / ".test-runs" / uuid4().hex
TEST_ROOT.mkdir(parents=True, exist_ok=True)

sys.path.insert(0, str(Path(__file__).parent))

from jarvis import core, report                      # noqa: E402
from jarvis.models import Paper, merge               # noqa: E402

TODAY = date(2026, 8, 9)
ok = fail = 0


def check(name, cond, extra=""):
    global ok, fail
    if cond:
        ok += 1
        print(f"  PASS  {name}")
    else:
        fail += 1
        print(f"  FAIL  {name} {extra}")


def _raises(fn, exc):
    """True when fn() raises the expected exception type."""
    try:
        fn()
    except exc:
        return True
    except Exception:                                    # noqa: BLE001
        return False
    return False


# ---------------------------------------------------------------- models
print("\n== models ==")
check("parse ISO", Paper.parse_date("2026-07-15") == date(2026, 7, 15))
check("parse arXiv ts", Paper.parse_date("2026-07-15T09:30:00Z") == date(2026, 7, 15))
check("parse PubMed '2026 Jul 15'", Paper.parse_date("2026 Jul 15") == date(2026, 7, 15))
check("parse year only", Paper.parse_date("2025") == date(2025, 1, 1))
check("garbage date -> None", Paper.parse_date("n/a") is None)

p = Paper(title="Deep Learning for ECG: A Review!", doi="10.1/ABC")
check("key prefers DOI", p.key == "doi:10.1/abc", p.key)
check("norm title", Paper(title="Deep Learning for ECG: A Review!").key
      == "title:deep learning for ecg a review")
check("age_days", Paper(title="x", published=date(2026, 8, 1)).age_days(TODAY) == 8)
check("author_str truncates", Paper(title="x", authors=list("abcdef")).author_str(4)
      == "a, b, c, d (+2)")

# ---------------------------------------------------------------- merge
print("\n== merge ==")
a = Paper(title="Short", abstract="x" * 10, published=date(2026, 6, 1),
          citations=3, source="arxiv", doi="")
b = Paper(title="Short but longer title", abstract="y" * 200,
          published=date(2026, 7, 1), citations=9, source="pubmed", doi="10.1/z")
m = merge(a, b)
check("keeps the longer title", m.title == "Short but longer title")
check("keeps the longer abstract", len(m.abstract) == 200)
check("citations = max", m.citations == 9)
check("published = earliest (the preprint)", m.published == date(2026, 6, 1))
check("doi taken from whichever record has it", m.doi == "10.1/z")
check("sources merged", m.source == "arxiv+pubmed", m.source)

# --------------------------------------------------------------- dedupe
print("\n== dedupe ==")
papers = [
    Paper(title="ECG Arrhythmia Detection with Transformers", doi="10.1/a", source="arxiv"),
    Paper(title="ECG arrhythmia detection with transformers.", doi="", source="pubmed"),
    Paper(title="ECG Arrhythmia Detection with Transformers", doi="10.1/A", source="openalex"),
    Paper(title="Completely different", doi="10.1/b", source="arxiv"),
    Paper(title="", doi="10.1/c", source="arxiv"),          # dropped: no title
]
d = core.dedupe(papers)
check("3 duplicates collapse into 1", len(d) == 2, f"got {len(d)}: {[x.title for x in d]}")
big = next(x for x in d if "ECG" in x.title)
check("dedupe merges the source list", set(big.source.split("+")) == {"arxiv", "pubmed", "openalex"},
      big.source)

# ---------------------------------------------------------------- score
print("\n== ranking ==")
new_rel = Paper(title="ECG arrhythmia detection deep learning",
                abstract="We propose a deep learning model for ECG arrhythmia detection. " * 4,
                published=TODAY - timedelta(days=5), citations=2, source="arxiv")
old_hot = Paper(title="ECG arrhythmia detection deep learning survey",
                abstract="A survey of ECG arrhythmia deep learning methods. " * 5,
                published=TODAY - timedelta(days=1500), citations=5000, source="openalex")
new_irr = Paper(title="Quantum chromodynamics lattice results",
                abstract="Lattice QCD computations of hadron masses. " * 5,
                published=TODAY - timedelta(days=3), citations=1, source="arxiv")
ranked = core.score([old_hot, new_irr, new_rel], "ECG arrhythmia deep learning", TODAY)
check("new and relevant ranks first", ranked[0] is new_rel,
      f"got {ranked[0].title[:40]} scores={[x.score for x in ranked]}")
check("new but off-topic ranks last", ranked[-1] is new_irr, ranked[-1].title[:40])
check("score stays within [0,1]", all(0 <= x.score <= 1 for x in ranked))
check("score_parts present", set(new_rel.score_parts) ==
      {"recency", "relevance", "impact", "multi_source"})
check("recency decays correctly", new_rel.score_parts["recency"] > 0.9
      and old_hot.score_parts["recency"] < 0.01)

# --------------------------------------------------------------- filters
print("\n== filters ==")
pool = [
    Paper(title="A", abstract="x" * 100, published=TODAY - timedelta(days=10), citations=5),
    Paper(title="B", abstract="short", published=TODAY, citations=100),      # short abstract
    Paper(title="C", abstract="x" * 100, published=TODAY - timedelta(days=400), citations=5),
    Paper(title="D retracted study", abstract="x" * 100, published=TODAY, citations=5),
]
f = core.apply_filters(pool, since=TODAY - timedelta(days=90), min_citations=1,
                       exclude_terms=["retracted"])
check("filters leave exactly one paper", len(f) == 1 and f[0].title == "A",
      [x.title for x in f])

# --------------------------------------------------------- parse real XML
print("\n== parse arXiv XML ==")
ARXIV_XML = """<?xml version="1.0"?>
<feed xmlns="http://www.w3.org/2005/Atom">
 <entry>
  <id>http://arxiv.org/abs/2607.12345v1</id>
  <published>2026-07-20T14:00:00Z</published>
  <title>Self-Supervised
  ECG Representation Learning</title>
  <summary>We present a  self-supervised
  framework for ECG.</summary>
  <author><name>Nguyen Van A</name></author>
  <author><name>Tran B</name></author>
  <link title="pdf" href="http://arxiv.org/pdf/2607.12345v1"/>
 </entry>
</feed>"""
root = ET.fromstring(ARXIV_XML)
ns = {"a": "http://www.w3.org/2005/Atom"}
e = root.find("a:entry", ns)
title = " ".join(e.findtext("a:title", "", ns).split())
check("wrapped title is joined", title == "Self-Supervised ECG Representation Learning",
      title)
check("published parses", Paper.parse_date(e.findtext("a:published", "", ns))
      == date(2026, 7, 20))
pdf = [l.get("href") for l in e.findall("a:link", ns) if l.get("title") == "pdf"]
check("pdf link extracted", pdf == ["http://arxiv.org/pdf/2607.12345v1"])

print("\n== parse OpenAlex inverted index ==")
inv = {"Deep": [0], "learning": [1], "for": [2], "ECG": [3]}
pos = {}
for w, idxs in inv.items():
    for i in idxs:
        pos[i] = w
check("abstract rebuilt from inverted index", " ".join(pos[i] for i in sorted(pos)) == "Deep learning for ECG")

# ---------------------------------------------------------------- report
print("\n== report ==")
demo = core.score([new_rel, old_hot], "ECG deep learning", TODAY)
demo[0].summary = "- Problem: arrhythmia detection\n- Method: transformer\n- Result: AUC 0.97"
demo[0].url = "https://arxiv.org/abs/2607.12345"

md = report.to_markdown(demo, "ECG deep learning")
check("markdown contains the title", "ECG arrhythmia detection deep learning" in md)
check("markdown contains the summary", "AUC 0.97" in md)

htm = report.to_html(demo, "ECG deep learning")
check("html well formed", htm.startswith("<!doctype html>") and htm.rstrip().endswith("</html>"))
check("html has the filter box", 'id="q"' in htm and "data-blob=" in htm)
check("html escapes XSS", "<script>alert" not in
      report.to_html([Paper(title="<script>alert(1)</script>", abstract="x" * 100)], "t"))

js = report.to_json(demo, "ECG deep learning")
import json                                                    # noqa: E402
parsed = json.loads(js)
check("json parses", parsed["count"] == 2 and len(parsed["papers"]) == 2)
check("json date -> ISO string", isinstance(parsed["papers"][0]["published"], str))

term = report.to_terminal(demo)
check("terminal output has links", "arxiv.org/abs" in term)
check("empty terminal output explains itself", "No papers found" in report.to_terminal([]))

outdir = Path(str(TEST_ROOT / 'jarvis-test-reports'))
path = report.write(demo, "ECG / deep learning!", outdir, "html")
check("file written", path.exists() and path.suffix == ".html", str(path))
check("filename slug is clean", " " not in path.name and "/" not in path.name, path.name)

# ------------------------------------------------------------------ CLI
print("\n== CLI ==")
from jarvis.cli import build_parser, PRESETS                   # noqa: E402
ns2 = build_parser().parse_args(["ecg", "deep", "learning", "--days", "30",
                                 "--format", "html", "--top", "5"])
check("parse args", " ".join(ns2.query) == "ecg deep learning"
      and ns2.days == 30 and ns2.format == "html" and ns2.top == 5)
check("all presets present", set(PRESETS) >= {"ecg", "medical-imaging", "cv", "clinical-ai"})
check("ecg preset uses arxiv categories",
      PRESETS["ecg"]["arxiv_categories"] == ["eess.SP", "cs.LG", "q-bio.QM"])

# ======================= SECOND BRAIN =======================

import shutil                                                  # noqa: E402
from jarvis import embed                                        # noqa: E402
from jarvis.brain import Brain                                  # noqa: E402
from jarvis.store import Store, fingerprint, node_text          # noqa: E402

print("\n== embed: vector ==")
e = embed.HashingEmbedder(dim=128)
e.fit(["ecg heart signal arrhythmia", "image segmentation ct scan",
       "ecg deep learning arrhythmia detection"])
v1 = e.encode_one("ecg arrhythmia heart")
v2 = e.encode_one("ecg arrhythmia heartbeat")
v3 = e.encode_one("image segmentation ct")
check("vector is L2-normalised", abs(sum(x * x for x in v1) - 1.0) < 1e-6)
check("same topic scores above different topic",
      embed.cosine(v1, v2) > embed.cosine(v1, v3),
      f"{embed.cosine(v1, v2):.3f} vs {embed.cosine(v1, v3):.3f}")
check("empty text -> zero vector", all(x == 0 for x in e.encode_one("")))
check("blob roundtrip", embed.from_blob(embed.to_blob(v1))[:5]
      == [round(x, 6) for x in []] or
      max(abs(a - b) for a, b in zip(embed.from_blob(embed.to_blob(v1)), v1)) < 1e-6)
check("get_embedder falls back to hashing",
      embed.get_embedder("khong-ton-tai-xyz", ["a b c"]).name == "hashing-tfidf")

print("\n== embed: knn + kmeans ==")
vecs = {"a": e.encode_one("ecg arrhythmia heart signal"),
        "b": e.encode_one("ecg heartbeat arrhythmia detection"),
        "c": e.encode_one("ct scan image segmentation"),
        "d": e.encode_one("mri image segmentation volumetric")}
edges = embed.knn(vecs, k=2, min_sim=0.0)
pairs = {frozenset((a, b)) for a, b, _ in edges}
check("knn emits no reversed duplicates", len(edges) == len(pairs))
check("knn never links a node to itself", all(a != b for a, b, _ in edges))
check("a-b linked (same ECG topic)", frozenset(("a", "b")) in pairs, str(pairs))
km = embed.kmeans(vecs, k=2)
check("kmeans assigns every node", set(km) == set(vecs))
check("kmeans separates the two topics", km["a"] == km["b"] and km["c"] == km["d"]
      and km["a"] != km["c"], str(km))

print("\n== store: nodes ==")
st = Store(str(TEST_ROOT / 'jt-brain/db.sqlite'))
st.ensure_workspace("default")

n1 = st.upsert_node(kind="note", title="ECG filtering",
                    body="bandpass 0.5-40Hz baseline wander", tags="ecg, dsp")
n2 = st.upsert_node(kind="concept", title="Contrastive learning",
                    body="SimCLR MoCo positive negative pairs")
check("creating a node returns an id", bool(n1) and n1 != n2)
check("node reads back", st.get_node(n1)["title"] == "ECG filtering")
check("tags parse into a list", st.get_node(n1)["tag_list"] == ["ecg", "dsp"])
check("meta defaults to a dict", st.get_node(n1)["meta"] == {})

st.upsert_node(kind="note", title="ECG filtering v2", node_id=n1)
check("update keeps the same id", st.get_node(n1)["title"] == "ECG filtering v2")
check("update does not create a new node", len(st.list_nodes()) == 2)

pk = "doi:10.1/xyz"
pa = st.upsert_node(kind="paper", title="A paper", paper_key=pk)
pb = st.upsert_node(kind="paper", title="A paper (updated)", paper_key=pk)
check("same paper_key does not duplicate", pa == pb and len(st.list_nodes()) == 3)
check("other workspace keeps its own copy",
      st.upsert_node(kind="paper", title="A paper", paper_key=pk,
                     workspace="other") != pa)

check("counts_by_kind correct", st.counts_by_kind()["note"] == 1
      and st.counts_by_kind()["paper"] == 1, str(st.counts_by_kind()))
check("filter by kind", len(st.list_nodes(kind="concept")) == 1)
check("substring search", len(st.list_nodes(query="Contrastive")) == 1)
check("invalid kind rejected",
      _raises(lambda: st.upsert_node(kind="bad", title="x"), ValueError))
check("empty title rejected",
      _raises(lambda: st.upsert_node(kind="note", title="   "), ValueError))

print("\n== store: fingerprint ==")
f1 = fingerprint(st.get_node(n1))
st.upsert_node(kind="note", title="ECG filtering v2", body="changed content", node_id=n1)
check("content change -> fingerprint change", fingerprint(st.get_node(n1)) != f1)
check("node_text includes tags", "dsp" in node_text(
    {"title": "t", "body": "b", "tags": "dsp"}))

print("\n== brain: pipeline ==")
# add overlapping content so the links mean something
st.upsert_node(kind="note", title="ECG filtering", node_id=n1,
               body="bandpass filter baseline wander heartbeat signal")
st.upsert_node(kind="journal", title="Filter experiments",
               body="tried bandpass filter on heartbeat signal, baseline wander gone")
br = Brain(st)
r = br.refresh()
check("reindex covers every node", r["indexed"] == r["total"] and r["total"] == 4,
      str(r))
check("second reindex skips everything", br.reindex()["indexed"] == 0)
check("links were built", r["links"] >= 1, str(r))

hits = br.search("bandpass filter for heart signals", top=3)
check("semantic search returns hits", len(hits) > 0)
check("top hit is on the filtering topic",
      "filter" in hits[0]["title"].lower() or "ECG" in hits[0]["title"],
      hits[0]["title"] if hits else "rỗng")
check("hits carry a similarity score", all("similarity" in h for h in hits))
check("hits sorted descending",
      all(hits[i]["similarity"] >= hits[i + 1]["similarity"]
          for i in range(len(hits) - 1)))

g = br.graph()
check("graph has every node", len(g["nodes"]) == 4)
check("graph has a category per kind", len(g["categories"]) == 6)
check("nodes carry colour and cluster", all("color" in n and "cluster" in n for n in g["nodes"]))
check("category counts sum to node count",
      sum(c["count"] for c in g["categories"]) == len(g["nodes"]))

print("\n== brain: cleanup on delete ==")
before_v, before_l = len(st.get_vectors()), len(st.links())
st.delete_node(n1)
check("deleting a node drops its vector", len(st.get_vectors()) == before_v - 1)
check("deleting a node drops its edges",
      not any(n1 in (l["src"], l["dst"]) for l in st.links()))
check("workspaces isolate data",
      len(st.list_nodes(workspace="other")) == 1 and len(st.list_nodes()) == 3)

print("\n== accented (non-ASCII) text must index ==")
stv = Store(str(TEST_ROOT / 'jt-vi/db.sqlite'))
stv.ensure_workspace("default")
# NOTE: this data stays accented on purpose - it is the regression test
# for the tokenizer bug that made non-ASCII notes unindexable.
stv.upsert_node(kind="note", title="Xử lý tín hiệu điện tim",
                body="lọc nhiễu đường nền, phát hiện đỉnh R, phân đoạn nhịp tim")
stv.upsert_node(kind="note", title="Phân đoạn ảnh y tế",
                body="chụp cắt lớp, cộng hưởng từ, phân đoạn cấu trúc giải phẫu")
stv.upsert_node(kind="concept", title="Tín hiệu điện tim",
                body="nhịp tim, loạn nhịp, phát hiện đỉnh R trên tín hiệu")
brv = Brain(stv)
rv = brv.refresh()
check("accented text tokenises",
      len(embed.tokenize("phân tích tín hiệu điện tim")) >= 4,
      str(embed.tokenize("phân tích tín hiệu điện tim")))
check("accented nodes get non-zero vectors",
      all(any(x != 0 for x in v) for v in stv.get_vectors().values()))
check("accented nodes get linked", rv["links"] >= 1, str(rv))
vh = brv.search("loạn nhịp tim và đỉnh R", top=2)
check("semantic search works on accented text", len(vh) > 0 and "tim" in vh[0]["title"].lower(),
      vh[0]["title"] if vh else "rỗng")

print("\n== brain: adaptive link threshold ==")
st2 = Store(str(TEST_ROOT / 'jt-brain2/db.sqlite'))
st2.ensure_workspace("default")
for i, (k, t, b) in enumerate([
        ("note", "ECG signal filtering", "bandpass baseline wander heartbeat"),
        ("note", "ECG beat segmentation", "R-peak detection heartbeat windows"),
        ("concept", "Transformer", "self attention positional encoding"),
        ("concept", "Diffusion model", "denoising probabilistic image synthesis"),
        ("goal", "Train ECG model", "arrhythmia classification transformer"),
        ("journal", "Notes today", "read transformer paper attention heartbeat")]):
    st2.upsert_node(kind=k, title=t, body=b)
br2 = Brain(st2)
res = br2.refresh()
check("no isolated nodes", len(br2.gaps()) == 0,
      str([x["title"] for x in br2.gaps()]))
check("edge density at least 1 per node",
      res["links"] >= len(st2.list_nodes()), str(res))

print("\n== migration from an older database ==")
# Regression: v1 shipped a `summary_vi` column. CREATE TABLE IF NOT EXISTS does
# not touch an existing table, so upgrading used to crash with
# "OperationalError: table seen has no column named summary".
import sqlite3                                                 # noqa: E402
import os                                                      # noqa: E402

os.makedirs(str(TEST_ROOT / 'jt-mig'))
old_db = str(TEST_ROOT / 'jt-mig/old.sqlite')
_c = sqlite3.connect(old_db)
_c.executescript("""
CREATE TABLE seen (key TEXT PRIMARY KEY, title TEXT NOT NULL, doi TEXT, url TEXT,
 published TEXT, venue TEXT, citations INTEGER DEFAULT 0, source TEXT, score REAL,
 topic TEXT, summary_vi TEXT, first_seen TEXT NOT NULL);
CREATE TABLE runs (id INTEGER PRIMARY KEY AUTOINCREMENT, topic TEXT, query TEXT,
 ran_at TEXT, n_found INTEGER, n_new INTEGER, report TEXT);
""")
_c.execute("INSERT INTO seen VALUES ('doi:10.1/old','Old paper','10.1/old','http://x',"
           "'2026-01-01','arXiv',5,'arxiv',0.5,'ecg','old summary text','2026-01-02T00:00')")
_c.commit()
_c.close()

st_mig = Store(old_db)
_cols = {r[1] for r in sqlite3.connect(old_db).execute("PRAGMA table_info(seen)")}
check("summary_vi renamed to summary", "summary" in _cols and "summary_vi" not in _cols,
      str(sorted(_cols)))
_row = sqlite3.connect(old_db).execute("SELECT summary FROM seen").fetchone()
check("existing summaries survive the rename", _row[0] == "old summary text", str(_row))

_p = Paper(title="Written after migration", abstract="x" * 200,
           published=date.today(), doi="10.1/new")
_p.summary = "- Problem: x"
check("mark_seen works after migration", st_mig.mark_seen([_p], topic="t") == 1)
check("brain tables created on the old DB too",
      bool(st_mig.ensure_workspace("default")) and
      bool(st_mig.upsert_node(kind="note", title="post migration")))
Store(old_db)
Store(old_db)
check("migration is idempotent",
      {r[1] for r in sqlite3.connect(old_db).execute("PRAGMA table_info(seen)")} == _cols)

print(f"\n{'=' * 46}\n  {ok} passed, {fail} failed\n{'=' * 46}")
sys.exit(1 if fail else 0)
