# Validation

Checked on September 12, 2026 with Python 3.12 on Windows.

- `python test_jarvis.py`: **91 passed, 0 failed**.
- `python demo_offline.py`: **16/16 passed**.
- All application Python files parse successfully.
- The publication copy uses unique `.test-runs/` fixture directories; the original project and database remain untouched.

Covered areas include date parsing, deduplication, ranking, filters, XML parsing, report escaping, CLI arguments, embedding normalization, similarity search, graph construction, workspace isolation, Vietnamese tokenization and SQLite schema migration. The demo checks that a second digest includes only new papers and writes a separate report.

No live academic API calls, paid LLM requests, model downloads, scheduled-task registration or personal-data export were performed. The optional SentenceTransformer backend was unavailable; offline validation used the hashing backend. The tests do not establish production security or live provider availability.
