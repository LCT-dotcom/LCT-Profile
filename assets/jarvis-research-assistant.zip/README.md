# Jarvis Research Assistant

**Lý Chính Tân · Personal research software**

A local research assistant for discovering papers, preparing reading digests and organizing a personal knowledge library. This public-source package is prepared from my existing Jarvis project; personal databases, reports, logs and configured topics are excluded.

## Features in the source

- Search adapters for arXiv, PubMed, OpenAlex, Semantic Scholar, Europe PMC and a preprint search source.
- Concurrent retrieval, DOI/title deduplication, date and keyword filtering, and transparent recency/relevance/citation scoring.
- Markdown, HTML, JSON and terminal reports, with SQLite persistence for seen papers and repeated digests.
- Optional Vietnamese summaries and query expansion through configured LLM providers or local Ollama.
- A local browser interface and a knowledge library for papers, notes, concepts, goals, journals and highlights.
- Similarity links, clusters and search with an offline hashing backend; an optional SentenceTransformer adapter is present for richer embeddings.

## Quick start

Use Python 3.12 or later from the repository root:

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
Copy-Item topics.example.json topics.json
python -m jarvis.web --install-dir . --config topics.json --port 8766 --no-browser
```

Open `http://127.0.0.1:8766/`. The server binds to loopback. This startup command does not create a scheduled task or install a system service. The original machine-specific installer and drive-specific launchers are not part of this publication package.

For the command-line interface:

```powershell
python -m jarvis --list-presets
python -m jarvis "ECG arrhythmia deep learning" --days 60 --top 15 --format markdown
```

On macOS/Linux, activate with `source .venv/bin/activate` and copy the example config with `cp`.

## Offline validation

```powershell
python test_jarvis.py
python demo_offline.py
```

Both commands use fixture data. Each run writes to a unique `.test-runs/` folder; it does not delete a previous database. Results are recorded in `VALIDATION.md`. Offline tests do not establish live API availability, provider access, summarization quality or production security.

## Optional services and data flow

Paper searches send queries to the selected academic services. Optional LLM summarization/query expansion sends the relevant text to the configured provider; Ollama can be used locally. Configure credentials through environment variables, never through committed files. Provider access, quotas and API policies may change. The hashing backend works without a model download; the optional SentenceTransformer backend requires its own package and model setup.

## Structure

| Module | Responsibility |
|---|---|
| `models.py`, `sources.py`, `core.py` | Paper model, API adapters, retrieval/filtering/ranking |
| `llm.py`, `report.py` | Optional summaries and report formats |
| `store.py`, `digest.py` | SQLite persistence and recurring-digest logic |
| `embed.py`, `brain.py` | Similarity indexing, links, clusters and knowledge search |
| `cli.py`, `web.py`, `ui.py` | Command-line and local browser interfaces |

The package preserves the existing application implementation. Changes for publication are limited to documentation, an example configuration, ignored personal artifacts and portable isolated offline-test paths.

Author: [LCT-dotcom](https://github.com/LCT-dotcom). Research assistance software; generated summaries and rankings should be checked against the original papers.
