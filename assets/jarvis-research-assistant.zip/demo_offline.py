"""End-to-end demo that needs NO network.

The API layer is swapped for fixture data; everything else is the real pipeline:
gather -> dedupe -> filter -> store.filter_new -> score -> render HTML.

It runs twice in a row to prove the second run does NOT repeat what the first
already reported - exactly how the scheduled digest behaves day to day.

    python demo_offline.py
"""

from __future__ import annotations

import logging
import shutil
import sys
from datetime import date, timedelta
from pathlib import Path
from uuid import uuid4

TEST_ROOT = Path(__file__).resolve().parent / ".test-runs" / uuid4().hex
TEST_ROOT.mkdir(parents=True, exist_ok=True)

sys.path.insert(0, str(Path(__file__).parent))

from jarvis import digest                       # noqa: E402
from jarvis.llm import LLM                      # noqa: E402
from jarvis.models import Paper                 # noqa: E402
from jarvis.store import Store                  # noqa: E402

TODAY = date.today()


def d(n):
    return TODAY - timedelta(days=n)


# ---- fixture: stands in for the API responses ----------------------------
# Day 1: one batch per topic. Day 2: a couple of new papers plus repeats.

FIXTURE = {
    "ECG electrocardiogram deep learning arrhythmia detection": {
        "day1": [
            Paper(title="Self-Supervised Pretraining for 12-Lead ECG Arrhythmia Classification",
                  abstract="We present a self-supervised pretraining framework for 12-lead ECG "
                           "signals using masked signal modeling. Pretrained on 800k unlabeled "
                           "recordings, our model reaches AUC 0.962 on PTB-XL arrhythmia "
                           "classification, outperforming supervised baselines by 4.1 points "
                           "under limited-label regimes.",
                  authors=["L. Chen", "M. Rossi", "K. Tanaka"], published=d(3),
                  url="https://arxiv.org/abs/2608.01234", pdf_url="https://arxiv.org/pdf/2608.01234",
                  venue="arXiv", citations=1, source="arxiv"),
            # same paper, journal version -> must collapse into one
            Paper(title="Self-supervised pretraining for 12-lead ECG arrhythmia classification.",
                  abstract="We present a self-supervised pretraining framework for 12-lead ECG.",
                  authors=["Lei Chen", "Marco Rossi"], published=d(1),
                  url="https://pubmed.ncbi.nlm.nih.gov/40123456/", doi="10.1016/j.ecg.2026.01.004",
                  venue="Computers in Biology and Medicine", citations=2, source="pubmed"),
            Paper(title="Transformer-Based Atrial Fibrillation Detection on Wearable Single-Lead ECG",
                  abstract="Atrial fibrillation detection on consumer wearables is limited by motion "
                           "artifact. We propose a lightweight transformer with artifact-aware "
                           "attention, achieving sensitivity 0.94 and specificity 0.97 on a "
                           "prospective cohort of 3,200 participants while running at 12 mW.",
                  authors=["S. Patel", "R. Okafor"], published=d(8),
                  url="https://arxiv.org/abs/2607.09876", venue="arXiv",
                  citations=6, source="arxiv"),
            Paper(title="A Survey of Deep Learning for Electrocardiogram Analysis",
                  abstract="This survey reviews 340 papers on deep learning for ECG analysis "
                           "published between 2018 and 2025, covering architectures, datasets, "
                           "evaluation protocols and clinical deployment barriers.",
                  authors=["J. Wu", "A. Novak", "P. Silva", "T. Ba", "Q. Lin"], published=d(700),
                  url="https://doi.org/10.1109/RBME.2025.001", doi="10.1109/RBME.2025.001",
                  venue="IEEE Reviews in Biomedical Engineering", citations=1840,
                  source="openalex"),
            Paper(title="RETRACTED: Fabricated ECG dataset study", abstract="x" * 200,
                  published=d(2), url="https://example.org/r", venue="J. Dubious",
                  citations=0, source="openalex"),
            Paper(title="Short metadata only", abstract="too short",
                  published=d(1), venue="X", source="openalex"),
        ],
        "day2": [
            Paper(title="Foundation Model for Continuous ECG Monitoring in the ICU",
                  abstract="We train a 1.2B-parameter foundation model on 4.1 million hours of "
                           "continuous ICU ECG telemetry. Fine-tuned with 200 labels it predicts "
                           "hemodynamic deterioration 6 hours ahead with AUROC 0.88, and transfers "
                           "zero-shot to three external hospital systems.",
                  authors=["N. Haddad", "E. Berg"], published=d(1),
                  url="https://arxiv.org/abs/2608.05555", venue="arXiv",
                  citations=0, source="arxiv"),
        ],
    },
    "medical image segmentation CT MRI X-ray deep learning": {
        "day1": [
            Paper(title="Prompt-Free Universal Segmentation for Volumetric CT",
                  abstract="Interactive segmentation models require prompts that clinicians rarely "
                           "have time to provide. We introduce a prompt-free universal segmenter "
                           "for volumetric CT covering 117 anatomical structures, reaching mean "
                           "Dice 0.891 on TotalSegmentator without any user interaction.",
                  authors=["Y. Zhang", "F. Moreau"], published=d(5),
                  url="https://arxiv.org/abs/2608.02222", venue="arXiv",
                  citations=3, source="arxiv"),
            Paper(title="Uncertainty-Aware Brain Tumor Segmentation with Conformal Prediction",
                  abstract="We wrap a nnU-Net backbone with split conformal prediction to produce "
                           "segmentation masks with finite-sample coverage guarantees. On BraTS "
                           "2025 the method attains 90% empirical coverage while inflating volume "
                           "estimates by only 7%, enabling safer radiotherapy planning.",
                  authors=["I. Kovacs", "D. Mbeki", "H. Sato"], published=d(12),
                  url="https://pubmed.ncbi.nlm.nih.gov/40222333/",
                  doi="10.1016/j.media.2026.103500",
                  venue="Medical Image Analysis", citations=11, source="pubmed"),
        ],
        "day2": [
            Paper(title="Prompt-Free Universal Segmentation for Volumetric CT",
                  abstract="Interactive segmentation models require prompts that clinicians rarely "
                           "have time to provide. We introduce a prompt-free universal segmenter.",
                  authors=["Y. Zhang"], published=d(6), url="https://arxiv.org/abs/2608.02222",
                  venue="arXiv", citations=4, source="openalex"),   # repeat of day 1 -> must be suppressed
            Paper(title="Cross-Modality MRI-to-CT Synthesis with Rectified Flow",
                  abstract="Paired MRI-CT data is scarce. We apply rectified flow matching to "
                           "unpaired cross-modality synthesis, cutting sampling steps from 250 to "
                           "4 while improving MAE from 68.2 HU to 51.7 HU on pelvic scans.",
                  authors=["G. Lim", "B. Andersson"], published=d(2),
                  url="https://arxiv.org/abs/2608.06666", venue="arXiv",
                  citations=0, source="arxiv"),
        ],
    },
}

CFG = {
    "install_dir": str(TEST_ROOT / 'jarvis-demo'),
    "days": 30,
    "top_per_topic": 5,
    "per_source": 30,
    "summarize": False,
    "open_after_run": False,
    "topics": [
        {"name": "ECG / cardiac signals",
         "query": "ECG electrocardiogram deep learning arrhythmia detection",
         "sources": ["arxiv", "pubmed", "openalex"],
         "exclude": ["retracted"]},
        {"name": "Medical imaging / segmentation",
         "query": "medical image segmentation CT MRI X-ray deep learning",
         "sources": ["arxiv", "pubmed", "openalex"]},
    ],
}


def make_gather(day: str):
    """Stands in for core.gather - returns fixtures instead of calling APIs."""
    def fake_gather(query, sources, limit, since, opts=None):
        batches = FIXTURE.get(query, {})
        out = list(batches.get("day1", []))
        if day == "day2":
            out += batches.get("day2", [])
        return out
    return fake_gather


def banner(t):
    print(f"\n{'=' * 66}\n  {t}\n{'=' * 66}")


def main() -> int:
    logging.basicConfig(level=logging.INFO, format="  [%(levelname)s] %(message)s")

    install = Path(CFG["install_dir"])
    store = Store(install / "data" / "jarvis.db")
    llm = LLM("auto")

    # ---------------- DAY 1 ----------------
    banner("NGAY 1 — Scheduled Task chay lan dau")
    p1, n1 = digest.run(CFG, store, llm, search_fn=make_gather("day1"))
    print(f"\n  -> {n1} bai moi | {p1}")

    # ---------------- DAY 2 ----------------
    banner("NGAY 2 — chay lai, fixture co them bai moi + lap lai bai cu")
    p2, n2 = digest.run(CFG, store, llm, search_fn=make_gather("day2"))
    print(f"\n  -> {n2} bai moi | {p2}")

    # ---------------- ASSERTIONS ----------------
    banner("KIEM CHUNG")
    checks = []

    html1 = p1.read_text(encoding="utf-8")
    html2 = p2.read_text(encoding="utf-8")

    checks.append(("Ngay 1 tim duoc bai", n1 > 0, f"n1={n1}"))
    checks.append(("Ngay 2 CHI bao bai moi (2 bai)", n2 == 2, f"n2={n2}"))
    lo1 = html1.lower()
    # count the rendered <h3> titles only, not the data-blob attribute
    import re
    titles1 = [t.lower() for t in re.findall(r"<h3><a [^>]*>(.*?)</a></h3>", html1)]
    checks.append(("Gop preprint arXiv + ban PubMed lam 1",
                   sum("pretraining for 12-lead ecg" in t for t in titles1) == 1,
                   f"titles={titles1}"))
    checks.append(("Ngay 1 render dung 4 the tieu de", len(titles1) == 4, str(len(titles1))))
    checks.append(("Bai gop hien ca 2 nguon",
                   "arxiv+pubmed" in lo1 or "pubmed+arxiv" in lo1, ""))
    checks.append(("two runs produce two files", p1 != p2, f"{p1.name} vs {p2.name}"))
    checks.append(("Loai bai RETRACTED", "RETRACTED" not in html1, ""))
    checks.append(("Loai bai abstract qua ngan", "Short metadata only" not in html1, ""))
    checks.append(("Ngay 2 KHONG lap bai cua ngay 1",
                   "Prompt-Free Universal Segmentation" not in html2, ""))
    checks.append(("Ngay 2 co bai foundation model moi",
                   "Foundation Model for Continuous ECG" in html2, ""))
    checks.append(("Ngay 2 co bai rectified flow moi",
                   "Cross-Modality MRI-to-CT Synthesis" in html2, ""))
    checks.append(("latest.html duoc cap nhat",
                   (install / "reports" / "latest.html").read_text(encoding="utf-8") == html2, ""))

    s = store.stats()
    checks.append(("DB luu du bai", s["total_papers"] == n1 + n2,
                   f"db={s['total_papers']} n1+n2={n1 + n2}"))
    checks.append(("DB ghi nhat ky 4 lan chay", s["total_runs"] == 4, str(s["total_runs"])))
    checks.append(("DB tach theo chu de", len(s["by_topic"]) == 2, str(s["by_topic"])))

    # the 700-day-old survey must be dropped by the 30-day window
    checks.append(("Cua so ngay loai bai 2 nam truoc",
                   "A Survey of Deep Learning for Electro" not in html1, ""))

    fails = 0
    for name, cond, extra in checks:
        print(f"  {'PASS' if cond else 'FAIL'}  {name} {'' if cond else extra}")
        fails += (not cond)

    banner("XEP HANG NGAY 1 (chu de ECG)")
    from jarvis import core
    raw = make_gather("day1")(CFG["topics"][0]["query"], [], 0, None)
    uniq = core.dedupe(raw)
    kept = core.apply_filters(uniq, date.today() - timedelta(days=30), 0,
                              exclude_terms=["retracted"])
    for i, p in enumerate(core.score(kept, CFG["topics"][0]["query"]), 1):
        sp = p.score_parts
        print(f"  {i}. [{p.score:.3f}]  moi={sp['recency']:.2f} "
              f"khop={sp['relevance']:.2f} anh_huong={sp['impact']:.2f} "
              f"da_nguon={sp['multi_source']:.2f}")
        print(f"     {p.title[:64]}")
        print(f"     {p.published} | {p.citations} cit | {p.source}")

    banner("THONG KE DB")
    print(f"  {s}")
    print(f"\n  File sinh ra:")
    for f in sorted(install.rglob("*")):
        if f.is_file():
            print(f"    {f.stat().st_size:>8,} B  {f.relative_to(install)}")

    print(f"\n{'=' * 66}")
    print(f"  {len(checks) - fails}/{len(checks)} kiem chung PASS")
    print(f"{'=' * 66}\n")
    return 1 if fails else 0


if __name__ == "__main__":
    sys.exit(main())
