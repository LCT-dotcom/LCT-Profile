"""Force console output to UTF-8.

On Windows, Python defaults stdout to the system code page (cp1252 / cp1258).
Printing any non-ASCII text to that console raises UnicodeEncodeError and kills
the whole script - even when the text only appears in a log line.

Call force_utf8() at the top of EVERY entry point, before printing anything.
"""

from __future__ import annotations

import sys

_done = False


def force_utf8() -> None:
    """Switch stdout/stderr to UTF-8, replacing unencodable characters instead
    of raising. Idempotent and safe on every OS."""
    global _done
    if _done:
        return
    _done = True

    for stream_name in ("stdout", "stderr"):
        stream = getattr(sys, stream_name, None)
        if stream is None:
            continue
        try:
            # Python 3.7+: TextIOWrapper.reconfigure
            stream.reconfigure(encoding="utf-8", errors="replace")
        except (AttributeError, ValueError, OSError):
            # stream replaced by another object (pytest, IDE, odd pipe) -> skip;
            # safe_text() is the second line of defence.
            pass


def safe_text(s: str) -> str:
    """Coerce a string into something printable on the current stream.

    Used when reconfigure failed (stdout already wrapped by another tool).
    """
    enc = getattr(sys.stdout, "encoding", None) or "utf-8"
    try:
        s.encode(enc)
        return s
    except (UnicodeEncodeError, LookupError):
        return s.encode(enc, errors="replace").decode(enc, errors="replace")
