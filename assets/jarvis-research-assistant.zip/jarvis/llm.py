"""LLM layer: query expansion + paper summarisation.

Three backends, chosen from the environment:
  ANTHROPIC_API_KEY -> Claude
  OPENAI_API_KEY    -> OpenAI
  OLLAMA_HOST       -> local Ollama (free, offline)
With none configured this layer is skipped and the pipeline runs unchanged.
"""

from __future__ import annotations

import json
import logging
import os
from concurrent.futures import ThreadPoolExecutor

import requests

from .models import Paper

log = logging.getLogger("jarvis.llm")

SUMMARY_PROMPT = """You are a biomedical research assistant. Read the abstract \
below and write a VERY SHORT summary of exactly three bullets:
- Problem: (one sentence)
- Method: (one sentence, name the architecture or technique if given)
- Result: (one sentence, quote concrete numbers if the abstract has them)

No preamble, nothing beyond those three lines.

Title: {title}
Abstract: {abstract}"""

EXPAND_PROMPT = """The user is looking for scientific papers about: "{query}"

Produce 4 English query variants for arXiv/PubMed covering synonyms and field \
specific terminology. Return ONLY a JSON array of strings, no explanation.
Example output: ["query 1", "query 2", "query 3", "query 4"]"""


class LLM:
    def __init__(self, backend: str = "auto", model: str | None = None):
        self.backend = self._resolve(backend)
        self.model = model or self._default_model()
        if self.backend:
            log.info("LLM: %s / %s", self.backend, self.model)
        else:
            log.info("No LLM backend configured - summaries disabled.")

    @staticmethod
    def _resolve(backend: str) -> str | None:
        if backend != "auto":
            return backend
        if os.getenv("ANTHROPIC_API_KEY"):
            return "anthropic"
        if os.getenv("OPENAI_API_KEY"):
            return "openai"
        if os.getenv("OLLAMA_HOST"):
            return "ollama"
        return None

    def _default_model(self) -> str:
        return {"anthropic": "claude-haiku-4-5-20251001",
                "openai": "gpt-4o-mini",
                "ollama": "qwen2.5:7b"}.get(self.backend or "", "")

    @property
    def enabled(self) -> bool:
        return self.backend is not None

    # ---- model call -----------------------------------------------------

    def complete(self, prompt: str, max_tokens: int = 400) -> str:
        if not self.enabled:
            return ""
        try:
            if self.backend == "anthropic":
                r = requests.post(
                    "https://api.anthropic.com/v1/messages",
                    headers={"x-api-key": os.environ["ANTHROPIC_API_KEY"],
                             "anthropic-version": "2023-06-01",
                             "content-type": "application/json"},
                    json={"model": self.model, "max_tokens": max_tokens,
                          "messages": [{"role": "user", "content": prompt}]},
                    timeout=90)
                r.raise_for_status()
                return r.json()["content"][0]["text"].strip()

            if self.backend == "openai":
                r = requests.post(
                    "https://api.openai.com/v1/chat/completions",
                    headers={"Authorization": f"Bearer {os.environ['OPENAI_API_KEY']}"},
                    json={"model": self.model, "max_tokens": max_tokens,
                          "messages": [{"role": "user", "content": prompt}]},
                    timeout=90)
                r.raise_for_status()
                return r.json()["choices"][0]["message"]["content"].strip()

            if self.backend == "ollama":
                host = os.getenv("OLLAMA_HOST", "http://localhost:11434")
                r = requests.post(f"{host}/api/generate",
                                  json={"model": self.model, "prompt": prompt,
                                        "stream": False},
                                  timeout=300)
                r.raise_for_status()
                return r.json().get("response", "").strip()
        except Exception as e:                # noqa: BLE001
            log.warning("LLM call failed: %s", e)
        return ""

    # ---- tasks ----------------------------------------------------------

    def expand_query(self, query: str) -> list[str]:
        """Generate query variants to improve recall."""
        raw = self.complete(EXPAND_PROMPT.format(query=query), 300)
        if not raw:
            return []
        try:
            start, end = raw.find("["), raw.rfind("]")
            variants = json.loads(raw[start:end + 1])
            return [v for v in variants if isinstance(v, str)][:4]
        except (ValueError, json.JSONDecodeError):
            log.warning("Could not parse query variants")
            return []

    def summarize_all(self, papers: list[Paper], workers: int = 4) -> list[Paper]:
        """Summarise in parallel. A failure leaves that one blank, others proceed."""
        if not self.enabled or not papers:
            return papers

        def one(p: Paper) -> None:
            if len(p.abstract) < 80:
                return
            p.summary = self.complete(
                SUMMARY_PROMPT.format(title=p.title, abstract=p.abstract[:4000]), 400)

        with ThreadPoolExecutor(max_workers=workers) as ex:
            list(ex.map(one, papers))
        return papers
