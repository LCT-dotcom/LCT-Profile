"""Shared paper schema used by every source."""

from __future__ import annotations

import re
from dataclasses import dataclass, field, asdict
from datetime import date, datetime
from typing import Any


def _norm_title(t: str) -> str:
    """Normalise a title for matching: strip punctuation, lowercase, squash spaces."""
    t = t.lower()
    t = re.sub(r"[^a-z0-9\s]", " ", t)
    return re.sub(r"\s+", " ", t).strip()


@dataclass
class Paper:
    title: str
    abstract: str = ""
    authors: list[str] = field(default_factory=list)
    published: date | None = None
    url: str = ""
    pdf_url: str = ""
    doi: str = ""
    venue: str = ""
    citations: int = 0
    source: str = ""            # arxiv | pubmed | openalex | semanticscholar | biorxiv | medrxiv
    external_ids: dict[str, str] = field(default_factory=dict)
    # filled in by the ranking / LLM layer
    score: float = 0.0
    score_parts: dict[str, float] = field(default_factory=dict)
    summary: str = ""

    # ---- helpers -------------------------------------------------------

    @property
    def key(self) -> str:
        """Dedupe key: DOI when present, otherwise the normalised title."""
        if self.doi:
            return "doi:" + self.doi.lower().strip()
        return "title:" + _norm_title(self.title)

    @property
    def norm_title(self) -> str:
        return _norm_title(self.title)

    @property
    def year(self) -> int | None:
        return self.published.year if self.published else None

    def age_days(self, today: date | None = None) -> float:
        if not self.published:
            return 3650.0
        today = today or date.today()
        return max((today - self.published).days, 0)

    def author_str(self, limit: int = 4) -> str:
        if not self.authors:
            return "N/A"
        if len(self.authors) <= limit:
            return ", ".join(self.authors)
        return ", ".join(self.authors[:limit]) + f" (+{len(self.authors) - limit})"

    def to_dict(self) -> dict[str, Any]:
        d = asdict(self)
        d["published"] = self.published.isoformat() if self.published else None
        return d

    @staticmethod
    def parse_date(value: Any) -> date | None:
        """Lenient date parsing across the different source APIs."""
        if value is None or value == "":
            return None
        if isinstance(value, datetime):
            return value.date()
        if isinstance(value, date):
            return value
        s = str(value).strip()
        for fmt in ("%Y-%m-%dT%H:%M:%SZ", "%Y-%m-%dT%H:%M:%S%z", "%Y-%m-%d",
                    "%Y/%m/%d", "%Y %b %d", "%Y %b", "%Y"):
            try:
                return datetime.strptime(s, fmt).date()
            except ValueError:
                continue
        m = re.match(r"(\d{4})", s)
        if m:
            try:
                return date(int(m.group(1)), 1, 1)
            except ValueError:
                return None
        return None


def merge(a: Paper, b: Paper) -> Paper:
    """Merge two duplicate records, keeping the richest field from each."""
    out = Paper(
        title=a.title if len(a.title) >= len(b.title) else b.title,
        abstract=a.abstract if len(a.abstract) >= len(b.abstract) else b.abstract,
        authors=a.authors or b.authors,
        published=a.published or b.published,
        url=a.url or b.url,
        pdf_url=a.pdf_url or b.pdf_url,
        doi=a.doi or b.doi,
        venue=a.venue or b.venue,
        citations=max(a.citations, b.citations),
        source="+".join(sorted({*a.source.split("+"), *b.source.split("+")} - {""})),
        external_ids={**b.external_ids, **a.external_ids},
    )
    # when sources disagree on the date, keep the earlier one (original preprint)
    if a.published and b.published:
        out.published = min(a.published, b.published)
    return out
