"""Clients for academic paper sources. Each returns list[Paper].

Every API below is FREE and works without a key.
Semantic Scholar is the exception worth a free key, to avoid rate limits.
"""

from __future__ import annotations

import logging
import time
import xml.etree.ElementTree as ET
from datetime import date, timedelta

import requests

from .models import Paper

log = logging.getLogger("jarvis.sources")

UA = "jarvis-research-bot/1.0 (mailto:you@example.com)"
TIMEOUT = 30


def _get(url: str, params: dict | None = None, headers: dict | None = None,
         retries: int = 3) -> requests.Response | None:
    """GET with retry + backoff. Returns None on hard failure so one dead source
    never takes down the whole pipeline."""
    h = {"User-Agent": UA, **(headers or {})}
    for attempt in range(retries):
        try:
            r = requests.get(url, params=params, headers=h, timeout=TIMEOUT)
            if r.status_code == 429 or r.status_code >= 500:
                wait = 2 ** attempt
                log.warning("%s -> %s, retrying in %ss", url, r.status_code, wait)
                time.sleep(wait)
                continue
            r.raise_for_status()
            return r
        except requests.RequestException as e:
            log.warning("Request to %s failed: %s (attempt %d)", url, e, attempt + 1)
            time.sleep(2 ** attempt)
    return None


# ---------------------------------------------------------------- arXiv

ARXIV_NS = {"a": "http://www.w3.org/2005/Atom"}


def search_arxiv(query: str, limit: int = 30, since: date | None = None,
                 categories: list[str] | None = None, **_) -> list[Paper]:
    """arXiv Atom API. Best source for CV / signal processing / ML.

    Example categories: eess.SP (signal processing), eess.IV (image & video),
    cs.CV, cs.LG, q-bio.QM.
    """
    q = f'(abs:"{query}" OR ti:"{query}")'
    if categories:
        cats = " OR ".join(f"cat:{c}" for c in categories)
        q = f"({q}) AND ({cats})"

    r = _get("http://export.arxiv.org/api/query", {
        "search_query": q,
        "start": 0,
        "max_results": limit,
        "sortBy": "submittedDate",
        "sortOrder": "descending",
    })
    if r is None:
        return []

    papers: list[Paper] = []
    root = ET.fromstring(r.text)
    for e in root.findall("a:entry", ARXIV_NS):
        def txt(tag: str) -> str:
            n = e.find(f"a:{tag}", ARXIV_NS)
            return (n.text or "").strip() if n is not None else ""

        pub = Paper.parse_date(txt("published"))
        if since and pub and pub < since:
            continue

        pdf = ""
        for link in e.findall("a:link", ARXIV_NS):
            if link.get("title") == "pdf":
                pdf = link.get("href", "")

        doi_node = e.find("{http://arxiv.org/schemas/atom}doi")

        papers.append(Paper(
            title=" ".join(txt("title").split()),
            abstract=" ".join(txt("summary").split()),
            authors=[(a.findtext("a:name", "", ARXIV_NS) or "").strip()
                     for a in e.findall("a:author", ARXIV_NS)],
            published=pub,
            url=txt("id"),
            pdf_url=pdf,
            doi=(doi_node.text or "").strip() if doi_node is not None else "",
            venue="arXiv",
            source="arxiv",
        ))
    return papers


# --------------------------------------------------------------- PubMed

EUTILS = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils"


def search_pubmed(query: str, limit: int = 30, since: date | None = None,
                  api_key: str | None = None, **_) -> list[Paper]:
    """PubMed E-utilities. The reference source for clinical medicine.

    Without a key: ~3 req/s. With a free NCBI key: 10 req/s.
    """
    params = {"db": "pubmed", "term": query, "retmax": limit,
              "retmode": "json", "sort": "date"}
    if since:
        params["mindate"] = since.strftime("%Y/%m/%d")
        params["maxdate"] = date.today().strftime("%Y/%m/%d")
        params["datetype"] = "pdat"
    if api_key:
        params["api_key"] = api_key

    r = _get(f"{EUTILS}/esearch.fcgi", params)
    if r is None:
        return []
    ids = r.json().get("esearchresult", {}).get("idlist", [])
    if not ids:
        return []

    fp = {"db": "pubmed", "id": ",".join(ids), "retmode": "xml"}
    if api_key:
        fp["api_key"] = api_key
    r2 = _get(f"{EUTILS}/efetch.fcgi", fp)
    if r2 is None:
        return []

    papers: list[Paper] = []
    root = ET.fromstring(r2.content)
    for art in root.findall(".//PubmedArticle"):
        pmid = art.findtext(".//PMID", "")
        title = "".join(art.find(".//ArticleTitle").itertext()) \
            if art.find(".//ArticleTitle") is not None else ""

        abst = " ".join(
            "".join(n.itertext()).strip()
            for n in art.findall(".//Abstract/AbstractText")
        ).strip()

        authors = []
        for a in art.findall(".//Author"):
            last, fore = a.findtext("LastName", ""), a.findtext("ForeName", "")
            name = f"{fore} {last}".strip() or a.findtext("CollectiveName", "")
            if name:
                authors.append(name)

        d = art.find(".//PubDate")
        pub = None
        if d is not None:
            y, m, dd = d.findtext("Year", ""), d.findtext("Month", ""), d.findtext("Day", "")
            pub = Paper.parse_date(" ".join(x for x in (y, m, dd) if x))

        doi = ""
        for aid in art.findall(".//ArticleId"):
            if aid.get("IdType") == "doi":
                doi = (aid.text or "").strip()

        papers.append(Paper(
            title=" ".join(title.split()),
            abstract=abst,
            authors=authors,
            published=pub,
            url=f"https://pubmed.ncbi.nlm.nih.gov/{pmid}/" if pmid else "",
            doi=doi,
            venue=art.findtext(".//Journal/Title", ""),
            source="pubmed",
            external_ids={"pmid": pmid} if pmid else {},
        ))
    return papers


# ------------------------------------------------------------- OpenAlex


def search_openalex(query: str, limit: int = 30, since: date | None = None,
                    mailto: str = "", **_) -> list[Paper]:
    """OpenAlex: metadata + citation counts for ~250M works. No key needed."""
    filters = ["has_abstract:true"]
    if since:
        filters.append(f"from_publication_date:{since.isoformat()}")

    params = {
        "search": query,
        "per-page": min(limit, 200),
        "sort": "publication_date:desc",
        "filter": ",".join(filters),
        "select": "id,doi,title,publication_date,cited_by_count,"
                  "authorships,primary_location,abstract_inverted_index",
    }
    if mailto:
        params["mailto"] = mailto

    r = _get("https://api.openalex.org/works", params)
    if r is None:
        return []

    papers: list[Paper] = []
    for w in r.json().get("results", []):
        # OpenAlex ships abstracts as an inverted index -> rebuild the text
        inv = w.get("abstract_inverted_index") or {}
        abstract = ""
        if inv:
            pos: dict[int, str] = {}
            for word, idxs in inv.items():
                for i in idxs:
                    pos[i] = word
            abstract = " ".join(pos[i] for i in sorted(pos))

        loc = w.get("primary_location") or {}
        src = loc.get("source") or {}

        papers.append(Paper(
            title=(w.get("title") or "").strip(),
            abstract=abstract,
            authors=[(a.get("author") or {}).get("display_name", "")
                     for a in (w.get("authorships") or [])][:20],
            published=Paper.parse_date(w.get("publication_date")),
            url=loc.get("landing_page_url") or w.get("id", ""),
            pdf_url=loc.get("pdf_url") or "",
            doi=(w.get("doi") or "").replace("https://doi.org/", ""),
            venue=src.get("display_name", ""),
            citations=w.get("cited_by_count", 0),
            source="openalex",
        ))
    return papers


# ------------------------------------------------------ Semantic Scholar


def search_semanticscholar(query: str, limit: int = 30, since: date | None = None,
                           api_key: str | None = None, **_) -> list[Paper]:
    """Semantic Scholar Graph API. Strong semantic matching + citation counts."""
    params = {
        "query": query,
        "limit": min(limit, 100),
        "fields": "title,abstract,authors,publicationDate,year,venue,"
                  "citationCount,externalIds,openAccessPdf,url",
    }
    if since:
        params["publicationDateOrYear"] = f"{since.isoformat()}:"

    headers = {"x-api-key": api_key} if api_key else {}
    r = _get("https://api.semanticscholar.org/graph/v1/paper/search", params, headers)
    if r is None:
        return []

    papers: list[Paper] = []
    for p in r.json().get("data", []):
        ext = p.get("externalIds") or {}
        oa = p.get("openAccessPdf") or {}
        papers.append(Paper(
            title=(p.get("title") or "").strip(),
            abstract=p.get("abstract") or "",
            authors=[a.get("name", "") for a in (p.get("authors") or [])],
            published=Paper.parse_date(p.get("publicationDate") or p.get("year")),
            url=p.get("url", ""),
            pdf_url=oa.get("url", ""),
            doi=ext.get("DOI", "") or "",
            venue=p.get("venue", ""),
            citations=p.get("citationCount", 0) or 0,
            source="semanticscholar",
            external_ids={k: str(v) for k, v in ext.items()},
        ))
    return papers


# --------------------------------------------------------- Europe PMC


def search_europepmc(query: str, limit: int = 30, since: date | None = None,
                     preprints_only: bool = False, **_) -> list[Paper]:
    """Europe PMC: covers PubMed plus preprints (bioRxiv, medRxiv). No key needed."""
    q = query
    if since:
        q += f' AND (FIRST_PDATE:[{since.isoformat()} TO {date.today().isoformat()}])'
    if preprints_only:
        q += " AND (SRC:PPR)"

    r = _get("https://www.ebi.ac.uk/europepmc/webservices/rest/search", {
        "query": q, "format": "json", "pageSize": min(limit, 100),
        "resultType": "core", "sort": "P_PDATE_D desc",
    })
    if r is None:
        return []

    papers: list[Paper] = []
    for it in r.json().get("resultList", {}).get("result", []):
        authors = [a.get("fullName", "")
                   for a in ((it.get("authorList") or {}).get("author") or [])]
        pmid, pmcid = it.get("pmid", ""), it.get("pmcid", "")
        url = (f"https://europepmc.org/article/{it.get('source', 'MED')}/{it.get('id', '')}")
        papers.append(Paper(
            title=(it.get("title") or "").strip().rstrip("."),
            abstract=it.get("abstractText") or "",
            authors=authors,
            published=Paper.parse_date(it.get("firstPublicationDate")),
            url=url,
            doi=it.get("doi", "") or "",
            venue=it.get("journalTitle", "") or ("Preprint" if it.get("source") == "PPR" else ""),
            citations=int(it.get("citedByCount", 0) or 0),
            source="europepmc",
            external_ids={k: v for k, v in (("pmid", pmid), ("pmcid", pmcid)) if v},
        ))
    return papers


def search_preprints(query: str, limit: int = 30, since: date | None = None, **kw):
    """Preprints only (bioRxiv/medRxiv/arXiv mirror): newest, not yet peer reviewed."""
    return search_europepmc(query, limit, since, preprints_only=True, **kw)


REGISTRY = {
    "arxiv": search_arxiv,
    "pubmed": search_pubmed,
    "openalex": search_openalex,
    "semanticscholar": search_semanticscholar,
    "europepmc": search_europepmc,
    "preprints": search_preprints,
}


def default_since(days: int) -> date:
    return date.today() - timedelta(days=days)
