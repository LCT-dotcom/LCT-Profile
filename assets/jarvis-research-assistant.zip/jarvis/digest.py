"""Automated digest: scan every topic, report ONLY new papers, one HTML file.

Entry point for scheduled runs:
    E:\\Jarvis\\.venv\\Scripts\\python.exe -m jarvis.digest --config E:\\Jarvis\\topics.json
"""

from __future__ import annotations

import argparse
import html
import json
import logging
import sys
import webbrowser
from datetime import date, datetime, timedelta
from pathlib import Path

from . import core
from ._console import force_utf8
from .llm import LLM
from .models import Paper
from .store import Store

log = logging.getLogger("jarvis.digest")

DEFAULT_CONFIG = {
    "install_dir": ".",
    "days": 7,
    "top_per_topic": 8,
    "per_source": 30,
    "summarize": False,
    "open_after_run": True,
    "topics": [
        {"name": "ECG / cardiac signals",
         "query": "ECG electrocardiogram deep learning arrhythmia detection",
         "sources": ["arxiv", "pubmed", "openalex", "europepmc"],
         "arxiv_categories": ["eess.SP", "cs.LG"]},
        {"name": "Medical imaging / segmentation",
         "query": "medical image segmentation CT MRI deep learning",
         "sources": ["arxiv", "pubmed", "openalex"],
         "arxiv_categories": ["eess.IV", "cs.CV"]},
        {"name": "Computer vision foundations",
         "query": "vision transformer foundation model self-supervised",
         "sources": ["arxiv", "semanticscholar"],
         "arxiv_categories": ["cs.CV"]},
    ],
}


def load_config(path: Path | None) -> dict:
    cfg = dict(DEFAULT_CONFIG)
    if path and path.exists():
        cfg.update(json.loads(path.read_text(encoding="utf-8")))
    return cfg


# ----------------------------------------------------------- run one topic


def run_topic(topic: dict, cfg: dict, store: Store, llm: LLM,
              search_fn=None) -> tuple[list[Paper], int]:
    """Returns (ranked new papers, total found before filtering against history)."""
    name = topic.get("name") or topic["query"][:40]
    query = topic["query"]
    since = date.today() - timedelta(days=cfg["days"])
    sources = topic.get("sources") or ["arxiv", "pubmed", "openalex", "europepmc"]

    opts = {}
    if topic.get("arxiv_categories"):
        opts["arxiv"] = {"categories": topic["arxiv_categories"]}

    gather = search_fn or core.gather
    raw = gather(query, sources, cfg["per_source"], since, opts)
    uniq = core.dedupe(raw)
    kept = core.apply_filters(uniq, since, topic.get("min_citations", 0),
                              exclude_terms=topic.get("exclude"))

    fresh = store.filter_new(kept)                       # <- the crucial step
    ranked = core.score(fresh, query)[:cfg["top_per_topic"]]

    if cfg.get("summarize") and llm.enabled:
        llm.summarize_all(ranked)

    store.mark_seen(ranked, topic=name)
    store.log_run(name, query, len(kept), len(ranked))
    log.info("%-28s found %3d | new %2d", name, len(kept), len(ranked))
    return ranked, len(kept)


# ------------------------------------------------------------ render


CSS = """
:root{--bg:#0f1115;--card:#171a21;--fg:#e6e8eb;--mut:#9aa3ad;--acc:#6ea8fe;
--br:#262b34;--ok:#4ade80}
*{box-sizing:border-box}
body{margin:0;padding:2rem 1rem;background:var(--bg);color:var(--fg);
font:15px/1.6 -apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif}
.wrap{max-width:900px;margin:0 auto}
h1{font-size:1.5rem;margin:0 0 .2rem}
.sub{color:var(--mut);font-size:.88rem;margin-bottom:1.6rem}
.bar{display:flex;gap:.6rem;flex-wrap:wrap;margin-bottom:1.6rem}
.stat{background:var(--card);border:1px solid var(--br);border-radius:9px;
padding:.6rem .9rem;font-size:.82rem}
.stat b{display:block;font-size:1.25rem;color:var(--acc)}
input{width:100%;padding:.65rem .9rem;background:var(--card);border:1px solid var(--br);
border-radius:8px;color:var(--fg);font-size:.93rem;margin-bottom:1.4rem}
h2.topic{font-size:1.05rem;margin:2rem 0 .9rem;padding-bottom:.5rem;
border-bottom:1px solid var(--br)}
h2.topic span{color:var(--mut);font-weight:400;font-size:.82rem;margin-left:.5rem}
.card{background:var(--card);border:1px solid var(--br);border-radius:11px;
padding:1rem 1.2rem;margin-bottom:.9rem}
.card h3{font-size:1rem;margin:0 0 .45rem;line-height:1.45;font-weight:600}
.card h3 a{color:var(--fg);text-decoration:none}
.card h3 a:hover{color:var(--acc)}
.meta{color:var(--mut);font-size:.8rem;margin-bottom:.55rem}
.tag{display:inline-block;background:#20252e;border:1px solid var(--br);border-radius:5px;
padding:1px 7px;margin-right:5px;font-size:.73rem}
.new{border-color:#2d5a3d;color:var(--ok)}
.sum{white-space:pre-wrap;font-size:.88rem;border-left:2px solid var(--acc);
padding-left:.85rem;margin:.5rem 0;color:#ccd2d9}
.abs{font-size:.85rem;color:var(--mut);max-height:4.4em;overflow:hidden}
.links a{color:var(--acc);text-decoration:none;font-size:.82rem;margin-right:.9rem}
.empty{color:var(--mut);font-style:italic;font-size:.9rem}
.hide{display:none}
footer{color:var(--mut);font-size:.78rem;margin-top:3rem;border-top:1px solid var(--br);
padding-top:1rem}
"""


def render(results: dict[str, list[Paper]], cfg: dict, stats: dict) -> str:
    e = html.escape
    total_new = sum(len(v) for v in results.values())
    sections = []

    for name, papers in results.items():
        cards = []
        if not papers:
            cards.append('<div class="empty">No new papers this period.</div>')
        for p in papers:
            links = []
            if p.url:
                links.append(f'<a href="{e(p.url)}" target="_blank">Page</a>')
            if p.pdf_url:
                links.append(f'<a href="{e(p.pdf_url)}" target="_blank">PDF</a>')
            if p.doi:
                links.append(f'<a href="https://doi.org/{e(p.doi)}" target="_blank">DOI</a>')
            body = (f'<div class="sum">{e(p.summary)}</div>' if p.summary
                    else f'<div class="abs">{e(p.abstract[:340])}…</div>' if p.abstract else "")
            blob = e((p.title + " " + " ".join(p.authors) + " " + p.venue
                      + " " + p.abstract).lower(), quote=True)
            cards.append(f"""<div class="card" data-blob="{blob}">
<h3><a href="{e(p.url)}" target="_blank">{e(p.title)}</a></h3>
<div class="meta">{p.published or 'n/a'} · {e(p.author_str(3))} · {e(p.venue or 'n/a')}</div>
<div><span class="tag new">NEW</span><span class="tag">{p.citations} citations</span>
<span class="tag">score {p.score}</span><span class="tag">{e(p.source)}</span></div>
{body}<div class="links">{' '.join(links)}</div></div>""")

        sections.append(f'<h2 class="topic">{e(name)}'
                        f'<span>{len(papers)} new</span></h2>'
                        + "\n".join(cards))

    return f"""<!doctype html><html lang="vi"><meta charset="utf-8">
<title>Jarvis Digest - {datetime.now():%d/%m/%Y}</title><style>{CSS}</style>
<div class="wrap">
<h1>Jarvis Digest</h1>
<div class="sub">{datetime.now():%A, %d/%m/%Y %H:%M} · {cfg['days']}-day window</div>
<div class="bar">
<div class="stat"><b>{total_new}</b>new today</div>
<div class="stat"><b>{len(results)}</b>topics tracked</div>
<div class="stat"><b>{stats['total_papers']}</b>papers in library</div>
<div class="stat"><b>{stats['total_runs']}</b>runs so far</div>
</div>
<input id="q" placeholder="Filter this digest…">
<div id="list">{''.join(sections)}</div>
<footer>Jarvis · data from arXiv, PubMed, OpenAlex, Europe PMC, Semantic Scholar.
Research reference only, not a basis for clinical decisions.</footer>
</div>
<script>
const inp=document.getElementById('q');
inp.addEventListener('input',()=>{{const v=inp.value.toLowerCase();
document.querySelectorAll('.card').forEach(c=>{{
c.classList.toggle('hide', v && !c.dataset.blob.includes(v));}});}});
</script></html>"""


# ------------------------------------------------------------ main


def run(cfg: dict, store: Store, llm: LLM, search_fn=None) -> tuple[Path, int]:
    results: dict[str, list[Paper]] = {}
    for topic in cfg["topics"]:
        name = topic.get("name") or topic["query"][:40]
        try:
            papers, _ = run_topic(topic, cfg, store, llm, search_fn)
            results[name] = papers
        except Exception as ex:                       # noqa: BLE001
            log.error("Topic '%s' failed: %s", name, ex)
            results[name] = []

    outdir = Path(cfg["install_dir"]) / "reports"
    outdir.mkdir(parents=True, exist_ok=True)

    # seconds + collision suffix so two runs seconds apart do not overwrite
    base = f"digest-{datetime.now():%Y%m%d-%H%M%S}"
    path = outdir / f"{base}.html"
    n = 1
    while path.exists():
        path = outdir / f"{base}-{n}.html"
        n += 1

    path.write_text(render(results, cfg, store.stats()), encoding="utf-8")

    latest = outdir / "latest.html"
    latest.write_text(path.read_text(encoding="utf-8"), encoding="utf-8")

    return path, sum(len(v) for v in results.values())


def main(argv: list[str] | None = None) -> int:
    force_utf8()
    ap = argparse.ArgumentParser(description="Jarvis automated digest")
    ap.add_argument("--config", type=Path, default=None)
    ap.add_argument("--install-dir", type=Path, default=None)
    ap.add_argument("--days", type=int, default=None)
    ap.add_argument("--no-open", action="store_true")
    ap.add_argument("--stats", action="store_true", help="Print stats and exit")
    ap.add_argument("-v", "--verbose", action="store_true")
    a = ap.parse_args(argv)

    logging.basicConfig(level=logging.INFO if a.verbose else logging.WARNING,
                        format="  [%(levelname)s] %(message)s")

    cfg = load_config(a.config)
    if a.install_dir:
        cfg["install_dir"] = str(a.install_dir)
    elif a.config:
        cfg.setdefault("install_dir", str(a.config.parent))
    if a.days:
        cfg["days"] = a.days

    store = Store(Path(cfg["install_dir"]) / "data" / "jarvis.db")

    if a.stats:
        s = store.stats()
        print(json.dumps(s, ensure_ascii=False, indent=2))
        return 0

    llm = LLM("auto")
    path, n = run(cfg, store, llm)
    print(f"  Digest: {n} new papers -> {path.resolve()}")

    if cfg.get("open_after_run") and not a.no_open:
        try:
            webbrowser.open(path.resolve().as_uri())
        except Exception:                              # noqa: BLE001
            pass
    return 0


if __name__ == "__main__":
    sys.exit(main())
