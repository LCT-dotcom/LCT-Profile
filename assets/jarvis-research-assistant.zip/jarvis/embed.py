"""Embedding layer: turn text into vectors so search works on MEANING, not keywords.

Two backends, picked automatically:

  1. sentence-transformers - high quality, needs an extra install (~400MB model
     plus torch). The default `allenai-specter` model is trained on scientific
     papers: it knows "myocardial infarction" is close to "heart attack", which
     keyword matching can never do.

  2. hashing TF-IDF (default) - pure Python, no dependency, nothing to download.
     Less subtle, but topic clustering still works and it runs instantly.

To enable backend 1:
    E:\\Jarvis\\.venv\\Scripts\\pip install sentence-transformers
    then set "embed_model": "allenai-specter" in topics.json

Vectors are always L2-normalised, so cosine similarity is a plain dot product.
"""

from __future__ import annotations

import array
import hashlib
import logging
import math
import re
from typing import Iterable, Sequence

log = logging.getLogger("jarvis.embed")

FALLBACK_DIM = 384

STOP = {
    "the", "a", "an", "of", "and", "or", "for", "in", "on", "with", "to", "from",
    "using", "based", "via", "by", "is", "are", "was", "were", "we", "our", "this",
    "that", "these", "those", "it", "its", "as", "at", "be", "been", "has", "have",
    "can", "may", "which", "such", "than", "then", "also", "however", "study",
    "paper", "method", "methods", "result", "results", "show", "shows", "propose",
    "proposed", "approach", "here", "used", "use", "both", "more", "most", "new",
}


def tokenize(text: str) -> list[str]:
    """UNICODE-AWARE tokenizer.

    [a-z0-9] silently destroys accented text: "phan tich tin hieu" written with
    diacritics collapses to one- and two-letter fragments that then get filtered
    out, leaving such notes with an empty vector - never linked, never found.
    \\w with re.UNICODE keeps accented characters intact.
    """
    words = re.findall(r"\w+", (text or "").lower(), re.UNICODE)
    return [w for w in words if len(w) > 2 and w not in STOP and not w.isdigit()]


# ------------------------------------------------------------ vector utils


def normalize(vec: list[float]) -> list[float]:
    n = math.sqrt(sum(v * v for v in vec))
    if n < 1e-12:
        return vec
    return [v / n for v in vec]


def cosine(a: Sequence[float], b: Sequence[float]) -> float:
    """Both inputs are L2-normalised, so this is the cosine similarity."""
    return sum(x * y for x, y in zip(a, b))


def to_blob(vec: Sequence[float]) -> bytes:
    return array.array("f", vec).tobytes()


def from_blob(blob: bytes) -> list[float]:
    a = array.array("f")
    a.frombytes(blob)
    return list(a)


# ------------------------------------------------------------- backends


class HashingEmbedder:
    """TF-IDF over a hashed feature space. Pure Python, nothing to download.

    Each token hashes to a fixed dimension; weight = tf * idf. IDF is estimated
    from the corpus itself via fit(); without fit() we fall back to raw tf.
    """

    name = "hashing-tfidf"

    def __init__(self, dim: int = FALLBACK_DIM):
        self.dim = dim
        self.idf: dict[int, float] = {}
        self.n_docs = 0

    @staticmethod
    def _bucket(token: str, dim: int) -> tuple[int, float]:
        h = hashlib.blake2b(token.encode("utf-8"), digest_size=8).digest()
        idx = int.from_bytes(h[:4], "little") % dim
        sign = 1.0 if h[4] & 1 else -1.0      # signed hashing reduces collisions
        return idx, sign

    def fit(self, texts: Iterable[str]) -> "HashingEmbedder":
        df: dict[int, int] = {}
        n = 0
        for t in texts:
            n += 1
            seen = set()
            for tok in tokenize(t):
                idx, _ = self._bucket(tok, self.dim)
                seen.add(idx)
            for idx in seen:
                df[idx] = df.get(idx, 0) + 1
        self.n_docs = n
        self.idf = {i: math.log((n + 1) / (c + 1)) + 1.0 for i, c in df.items()}
        log.info("hashing embedder fit on %d documents", n)
        return self

    def encode_one(self, text: str) -> list[float]:
        vec = [0.0] * self.dim
        toks = tokenize(text)
        if not toks:
            return vec
        tf: dict[int, float] = {}
        signs: dict[int, float] = {}
        for tok in toks:
            idx, sign = self._bucket(tok, self.dim)
            tf[idx] = tf.get(idx, 0.0) + 1.0
            signs[idx] = sign
        for idx, c in tf.items():
            w = (1.0 + math.log(c)) * self.idf.get(idx, 1.0)
            vec[idx] = signs[idx] * w
        return normalize(vec)

    def encode(self, texts: Sequence[str]) -> list[list[float]]:
        return [self.encode_one(t) for t in texts]


class SentenceTransformerEmbedder:
    """Wrapper around sentence-transformers. Only constructs if it is installed."""

    def __init__(self, model_name: str = "allenai-specter"):
        from sentence_transformers import SentenceTransformer   # noqa: PLC0415
        self.name = model_name
        self.model = SentenceTransformer(model_name)
        self.dim = int(self.model.get_sentence_embedding_dimension())
        log.info("using sentence-transformers: %s (dim=%d)", model_name, self.dim)

    def fit(self, texts):        # not needed, kept for interface parity
        return self

    def encode(self, texts: Sequence[str]) -> list[list[float]]:
        vecs = self.model.encode(list(texts), normalize_embeddings=True,
                                 show_progress_bar=False)
        return [list(map(float, v)) for v in vecs]

    def encode_one(self, text: str) -> list[float]:
        return self.encode([text])[0]


def get_embedder(model_name: str | None = None, corpus: Sequence[str] | None = None):
    """Return the best available embedder. Never raises.

    model_name of None or "hashing" uses the fallback directly, no import attempt.
    """
    if model_name and model_name != "hashing":
        try:
            return SentenceTransformerEmbedder(model_name)
        except ImportError:
            log.warning("sentence-transformers not installed - using hashing TF-IDF. "
                        "Install with: pip install sentence-transformers")
        except Exception as e:                      # noqa: BLE001
            log.warning("Could not load model '%s' (%s) - using hashing TF-IDF",
                        model_name, e)

    emb = HashingEmbedder()
    if corpus:
        emb.fit(corpus)
    return emb


# ----------------------------------------------------------------- kNN


def knn(vectors: dict[str, list[float]], k: int = 6,
        min_sim: float = 0.15) -> list[tuple[str, str, float]]:
    """k-nearest-neighbour edges, deduplicated so (a,b) == (b,a).

    O(n^2) - fine up to a few thousand nodes, plenty for a personal brain.
    """
    ids = list(vectors)
    edges: dict[tuple[str, str], float] = {}

    for i, a in enumerate(ids):
        va = vectors[a]
        sims: list[tuple[float, str]] = []
        for j, b in enumerate(ids):
            if i == j:
                continue
            s = cosine(va, vectors[b])
            if s >= min_sim:
                sims.append((s, b))
        sims.sort(reverse=True)
        for s, b in sims[:k]:
            key = (a, b) if a < b else (b, a)
            if s > edges.get(key, 0.0):
                edges[key] = s

    return [(a, b, round(w, 4)) for (a, b), w in
            sorted(edges.items(), key=lambda kv: -kv[1])]


def most_similar(query_vec: Sequence[float], vectors: dict[str, list[float]],
                 top: int = 10, exclude: set[str] | None = None
                 ) -> list[tuple[str, float]]:
    exclude = exclude or set()
    scored = [(nid, cosine(query_vec, v)) for nid, v in vectors.items()
              if nid not in exclude]
    scored.sort(key=lambda kv: -kv[1])
    return [(nid, round(s, 4)) for nid, s in scored[:top]]


# ------------------------------------------------------- light clustering


def kmeans(vectors: dict[str, list[float]], k: int = 6, iters: int = 25,
           seed: int = 7) -> dict[str, int]:
    """Simple cosine k-means in pure Python. Returns node_id -> cluster index.

    Drives colouring and the angular placement of nodes in the UI.
    """
    ids = list(vectors)
    if not ids:
        return {}
    k = max(1, min(k, len(ids)))
    dim = len(vectors[ids[0]])

    # trimmed k-means++ init: repeatedly take the point furthest from all centres
    import random
    rng = random.Random(seed)
    centers = [vectors[rng.choice(ids)][:]]
    while len(centers) < k:
        far, best = None, 2.0
        for nid in ids:
            v = vectors[nid]
            s = max(cosine(v, c) for c in centers)
            if s < best:
                best, far = s, v
        centers.append((far or vectors[rng.choice(ids)])[:])

    assign: dict[str, int] = {}
    for _ in range(iters):
        changed = False
        for nid in ids:
            v = vectors[nid]
            best_i = max(range(k), key=lambda i: cosine(v, centers[i]))
            if assign.get(nid) != best_i:
                assign[nid] = best_i
                changed = True

        sums = [[0.0] * dim for _ in range(k)]
        counts = [0] * k
        for nid, ci in assign.items():
            v = vectors[nid]
            s = sums[ci]
            for d in range(dim):
                s[d] += v[d]
            counts[ci] += 1
        for i in range(k):
            if counts[i]:
                centers[i] = normalize([x / counts[i] for x in sums[i]])
        if not changed:
            break

    return assign
