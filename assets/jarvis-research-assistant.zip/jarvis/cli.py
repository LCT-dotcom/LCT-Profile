"""Jarvis CLI - type a research field, get the newest papers from every source.

Usage:
    python -m jarvis                              # interactive mode
    python -m jarvis "ecg arrhythmia deep learning"
    python -m jarvis "brain tumor segmentation" --days 60 --top 15 --format html
    python -m jarvis --preset ecg
    python -m jarvis --list-presets
"""

from __future__ import annotations

import argparse
import logging
import sys
from datetime import date, timedelta
from pathlib import Path

from . import core, report
from ._console import force_utf8
from .llm import LLM

# ---- field presets: typing a preset name runs a tuned configuration ------

PRESETS: dict[str, dict] = {
    "ecg": {
        "query": "ECG electrocardiogram deep learning arrhythmia detection",
        "sources": ["arxiv", "pubmed", "openalex", "europepmc"],
        "arxiv_categories": ["eess.SP", "cs.LG", "q-bio.QM"],
    },
    "biosignal": {
        "query": "biosignal EEG PPG physiological signal processing machine learning",
        "sources": ["arxiv", "pubmed", "openalex"],
        "arxiv_categories": ["eess.SP", "cs.LG"],
    },
    "medical-imaging": {
        "query": "medical image segmentation CT MRI deep learning",
        "sources": ["arxiv", "pubmed", "openalex", "europepmc"],
        "arxiv_categories": ["eess.IV", "cs.CV"],
    },
    "cv": {
        "query": "computer vision foundation model vision transformer",
        "sources": ["arxiv", "openalex", "semanticscholar"],
        "arxiv_categories": ["cs.CV", "cs.LG"],
    },
    "clinical-ai": {
        "query": "clinical decision support large language model electronic health record",
        "sources": ["pubmed", "europepmc", "openalex", "arxiv"],
        "arxiv_categories": ["cs.CL", "cs.LG"],
    },
    "preprint": {
        "query": "medical artificial intelligence",
        "sources": ["preprints", "arxiv"],
        "arxiv_categories": None,
    },
}

DEFAULT_SOURCES = ["arxiv", "pubmed", "openalex", "europepmc"]


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="jarvis", description=__doc__,
                                formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("query", nargs="*", help="Field or keywords to search")
    p.add_argument("--preset", choices=list(PRESETS), help="Use a built-in field preset")
    p.add_argument("--list-presets", action="store_true")
    p.add_argument("--sources", nargs="+", default=None,
                   choices=["arxiv", "pubmed", "openalex", "semanticscholar",
                            "europepmc", "preprints"])
    p.add_argument("--days", type=int, default=90, help="Only papers from the last N days (default 90)")
    p.add_argument("--top", type=int, default=20, help="How many papers to keep after ranking")
    p.add_argument("--per-source", type=int, default=30)
    p.add_argument("--min-citations", type=int, default=0)
    p.add_argument("--exclude", nargs="+", default=None, help="Drop papers containing these words")
    p.add_argument("--format", choices=["markdown", "html", "json", "terminal"],
                   default="markdown")
    p.add_argument("--out", default="./reports", help="Where to write reports")
    p.add_argument("--summarize", action="store_true",
                   help="Summarise with an LLM (needs an API key or Ollama)")
    p.add_argument("--expand", action="store_true",
                   help="Use the LLM to generate extra query variants for recall")
    p.add_argument("--llm-backend", default="auto",
                   choices=["auto", "anthropic", "openai", "ollama"])
    p.add_argument("--llm-model", default=None)
    p.add_argument("-v", "--verbose", action="store_true")
    return p


def run_one(query: str, args, llm: LLM) -> list:
    since = date.today() - timedelta(days=args.days) if args.days > 0 else None

    preset = PRESETS.get(args.preset or "", {})
    sources = args.sources or preset.get("sources") or DEFAULT_SOURCES
    opts = {}
    if preset.get("arxiv_categories"):
        opts["arxiv"] = {"categories": preset["arxiv_categories"]}

    queries = [query]
    if args.expand and llm.enabled:
        extra = llm.expand_query(query)
        if extra:
            print(f"  Query variants: {extra}")
            queries += extra

    all_papers = []
    for q in queries:
        all_papers += core.gather(q, sources, args.per_source, since, opts)

    uniq = core.dedupe(all_papers)
    kept = core.apply_filters(uniq, since, args.min_citations,
                              exclude_terms=args.exclude)
    ranked = core.score(kept, query)[:args.top]

    if args.summarize and llm.enabled:
        print(f"  Summarising {len(ranked)} papers with {llm.backend}…")
        llm.summarize_all(ranked)
    elif args.summarize:
        print("  Skipping summaries: no LLM configured "
              "(set ANTHROPIC_API_KEY / OPENAI_API_KEY / OLLAMA_HOST).")

    return ranked, since


def emit(papers, query, args, since) -> None:
    if args.format == "terminal":
        print(report.to_terminal(papers))
        return
    path = report.write(papers, query, Path(args.out), args.format, since)
    print(f"\n  {len(papers)} papers -> {path.resolve()}")


def interactive(args, llm: LLM) -> None:
    print("\n  JARVIS - research paper scanner")
    print("  Type a field and press Enter. Commands: :presets  :days N  :top N  :fmt X  :q\n")
    while True:
        try:
            line = input("  field > ").strip()
        except (EOFError, KeyboardInterrupt):
            print()
            return
        if not line:
            continue
        if line in (":q", ":quit", "exit"):
            return
        if line == ":presets":
            for k, v in PRESETS.items():
                print(f"    {k:<16} {v['query']}")
            continue
        if line.startswith(":days "):
            args.days = int(line.split()[1]); print(f"    days = {args.days}"); continue
        if line.startswith(":top "):
            args.top = int(line.split()[1]); print(f"    top = {args.top}"); continue
        if line.startswith(":fmt "):
            args.format = line.split()[1]; print(f"    format = {args.format}"); continue

        if line in PRESETS:
            args.preset = line
            query = PRESETS[line]["query"]
        else:
            args.preset = None
            query = line

        print(f"  Scanning: {query} (last {args.days} days)…")
        papers, since = run_one(query, args, llm)
        emit(papers, query, args, since)
        print()


def main(argv: list[str] | None = None) -> int:
    force_utf8()
    args = build_parser().parse_args(argv)
    logging.basicConfig(
        level=logging.INFO if args.verbose else logging.WARNING,
        format="  [%(levelname)s] %(message)s")

    if args.list_presets:
        for k, v in PRESETS.items():
            print(f"{k:<16} {v['query']}")
        return 0

    llm = LLM(args.llm_backend, args.llm_model)

    query = " ".join(args.query).strip()
    if not query and args.preset:
        query = PRESETS[args.preset]["query"]

    if not query:
        interactive(args, llm)
        return 0

    papers, since = run_one(query, args, llm)
    emit(papers, query, args, since)
    return 0


if __name__ == "__main__":
    sys.exit(main())
