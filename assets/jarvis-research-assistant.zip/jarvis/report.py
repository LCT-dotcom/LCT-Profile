"""Output renderers: terminal, Markdown, HTML, JSON."""

from __future__ import annotations

import html
import json
from datetime import date, datetime
from pathlib import Path

from .models import Paper


def to_json(papers: list[Paper], query: str) -> str:
    return json.dumps({
        "query": query,
        "generated_at": datetime.now().isoformat(timespec="seconds"),
        "count": len(papers),
        "papers": [p.to_dict() for p in papers],
    }, ensure_ascii=False, indent=2)


def to_markdown(papers: list[Paper], query: str, since: date | None = None) -> str:
    L = [f"# Jarvis - latest papers on: {query}", ""]
    L.append(f"*Generated {datetime.now():%Y-%m-%d %H:%M} · {len(papers)} papers"
             + (f" · since {since.isoformat()}" if since else "") + "*")
    L.append("")

    for i, p in enumerate(papers, 1):
        d = p.published.isoformat() if p.published else "n/a"
        L.append(f"## {i}. {p.title}")
        L.append("")
        L.append(f"**{d}** · {p.author_str()} · *{p.venue or 'n/a'}* · "
                 f"{p.citations} citations · score `{p.score}` · `{p.source}`")
        L.append("")
        if p.summary:
            L.append(p.summary)
            L.append("")
        elif p.abstract:
            L.append("> " + p.abstract[:400].replace("\n", " ") + "…")
            L.append("")
        links = []
        if p.url:
            links.append(f"[Page]({p.url})")
        if p.pdf_url:
            links.append(f"[PDF]({p.pdf_url})")
        if p.doi:
            links.append(f"[DOI](https://doi.org/{p.doi})")
        if links:
            L.append(" · ".join(links))
            L.append("")
        L.append("---")
        L.append("")
    return "\n".join(L)


HTML_TMPL = """<!doctype html><html lang="vi"><meta charset="utf-8">
<title>Jarvis - {q}</title>
<style>
:root{{--bg:#0f1115;--card:#171a21;--fg:#e6e8eb;--mut:#9aa3ad;--acc:#6ea8fe;--br:#262b34}}
*{{box-sizing:border-box}}
body{{margin:0;padding:2rem 1rem;background:var(--bg);color:var(--fg);
font:15px/1.6 -apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif}}
.wrap{{max-width:860px;margin:0 auto}}
h1{{font-size:1.6rem;margin:0 0 .3rem}}
.sub{{color:var(--mut);font-size:.9rem;margin-bottom:2rem}}
.f{{margin-bottom:1.5rem}}
input{{width:100%;padding:.7rem .9rem;background:var(--card);border:1px solid var(--br);
border-radius:8px;color:var(--fg);font-size:.95rem}}
.card{{background:var(--card);border:1px solid var(--br);border-radius:12px;
padding:1.1rem 1.3rem;margin-bottom:1rem}}
.card h2{{font-size:1.05rem;margin:0 0 .5rem;line-height:1.4}}
.card h2 a{{color:var(--fg);text-decoration:none}}
.card h2 a:hover{{color:var(--acc)}}
.meta{{color:var(--mut);font-size:.82rem;margin-bottom:.7rem}}
.tag{{display:inline-block;background:#20252e;border:1px solid var(--br);border-radius:5px;
padding:1px 7px;margin-right:5px;font-size:.75rem}}
.sum{{white-space:pre-wrap;font-size:.9rem;border-left:2px solid var(--acc);
padding-left:.9rem;margin:.6rem 0;color:#ccd2d9}}
.abs{{font-size:.86rem;color:var(--mut);max-height:4.5em;overflow:hidden}}
.links a{{color:var(--acc);text-decoration:none;font-size:.84rem;margin-right:.9rem}}
.hide{{display:none}}
</style>
<div class="wrap">
<h1>Jarvis - {q}</h1>
<div class="sub">{n} papers · generated {t}</div>
<div class="f"><input id="q" placeholder="Filter by keyword, author, venue…"></div>
<div id="list">{cards}</div>
</div>
<script>
const inp=document.getElementById('q');
inp.addEventListener('input',()=>{{
  const v=inp.value.toLowerCase();
  document.querySelectorAll('.card').forEach(c=>{{
    c.classList.toggle('hide', v && !c.dataset.blob.includes(v));
  }});
}});
</script>
</html>"""


def to_html(papers: list[Paper], query: str) -> str:
    cards = []
    for i, p in enumerate(papers, 1):
        e = html.escape
        blob = e((p.title + " " + " ".join(p.authors) + " " + p.venue
                  + " " + p.abstract).lower(), quote=True)
        links = []
        if p.url:
            links.append(f'<a href="{e(p.url)}" target="_blank">Page</a>')
        if p.pdf_url:
            links.append(f'<a href="{e(p.pdf_url)}" target="_blank">PDF</a>')
        if p.doi:
            links.append(f'<a href="https://doi.org/{e(p.doi)}" target="_blank">DOI</a>')

        body = (f'<div class="sum">{e(p.summary)}</div>' if p.summary
                else f'<div class="abs">{e(p.abstract[:400])}…</div>' if p.abstract else "")

        cards.append(f"""<div class="card" data-blob="{blob}">
<h2>{i}. <a href="{e(p.url)}" target="_blank">{e(p.title)}</a></h2>
<div class="meta">{p.published or 'n/a'} · {e(p.author_str())} · {e(p.venue or 'n/a')}</div>
<div><span class="tag">{p.citations} citations</span>
<span class="tag">score {p.score}</span><span class="tag">{e(p.source)}</span></div>
{body}
<div class="links">{' '.join(links)}</div>
</div>""")

    return HTML_TMPL.format(q=html.escape(query), n=len(papers),
                            t=f"{datetime.now():%Y-%m-%d %H:%M}",
                            cards="\n".join(cards))


def to_terminal(papers: list[Paper]) -> str:
    if not papers:
        return "No papers found. Try widening --days or changing the keywords."
    L = []
    for i, p in enumerate(papers, 1):
        d = p.published.isoformat() if p.published else "n/a"
        L.append(f"\n[{i}] {p.title}")
        L.append(f"    {d} | {p.author_str(3)} | {p.venue or 'n/a'}")
        L.append(f"    {p.citations} cit | score {p.score} | {p.source}")
        if p.summary:
            L.extend("    " + ln for ln in p.summary.splitlines() if ln.strip())
        L.append(f"    {p.url}")
    return "\n".join(L)


def write(papers: list[Paper], query: str, outdir: Path, fmt: str,
          since: date | None = None) -> Path:
    outdir.mkdir(parents=True, exist_ok=True)
    slug = "".join(c if c.isalnum() else "-" for c in query.lower())[:50].strip("-")
    stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    ext = {"markdown": "md"}.get(fmt, fmt)
    path = outdir / f"{slug}-{stamp}.{ext}"
    n = 1
    while path.exists():                      # avoid clobbering back-to-back runs
        path = outdir / f"{slug}-{stamp}-{n}.{ext}"
        n += 1
    content = {"markdown": lambda: to_markdown(papers, query, since),
               "html": lambda: to_html(papers, query),
               "json": lambda: to_json(papers, query)}[fmt]()
    path.write_text(content, encoding="utf-8")
    return path
