"""Jarvis OS front end: glowing graph + second brain + paper discovery.

Kept out of web.py so that module only handles routing. All HTML/CSS/JS lives
in a single string - no CDN, no build step, open and it runs.
"""

PAGE = r"""<!doctype html>
<html lang="en"><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Jarvis OS</title>
<style>
:root{
  --bg:#080a0f; --bg2:#0d1017; --card:#141821; --fg:#e6e8eb; --mut:#7d8794;
  --acc:#6ea8fe; --br:#1f242e; --ok:#4ade80; --warn:#fbbf24; --danger:#f87171;
}
*{box-sizing:border-box}
html,body{height:100%}
body{margin:0;background:var(--bg);color:var(--fg);overflow:hidden;
font:14px/1.55 -apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif}
button,input,select,textarea{font:inherit;color:inherit}

/* ---------- top bar ---------- */
#top{height:46px;display:flex;align-items:center;gap:.7rem;padding:0 .9rem;
border-bottom:1px solid var(--br);background:var(--bg2);position:relative;z-index:20}
.brand{font-weight:700;letter-spacing:.13em;font-size:.82rem;color:var(--acc)}
.tabs{display:flex;gap:.2rem;margin-left:.6rem}
.tab{padding:.3rem .8rem;border-radius:7px;font-size:.82rem;color:var(--mut);
cursor:pointer;border:1px solid transparent}
.tab:hover{color:var(--fg)}
.tab.on{background:var(--card);border-color:var(--br);color:var(--fg)}
#top .sp{flex:1}
select,.btn{background:var(--card);border:1px solid var(--br);border-radius:7px;
padding:.32rem .6rem;font-size:.8rem;cursor:pointer}
.btn:hover{border-color:var(--acc)}
.btn.pri{background:var(--acc);color:#08101f;border-color:var(--acc);font-weight:600}
.stat{font-size:.74rem;color:var(--mut)}

/* ---------- layout ---------- */
#main{position:absolute;top:46px;left:0;right:0;bottom:0}
.view{position:absolute;inset:0;display:none}
.view.on{display:block}

/* ---------- graph ---------- */
#cv{display:block;width:100%;height:100%;cursor:grab}
#cv:active{cursor:grabbing}
.cat{position:absolute;pointer-events:none;font-size:.66rem;letter-spacing:.16em;
color:var(--mut);text-shadow:0 0 12px #000}
.cat b{display:block;font-size:.62rem;letter-spacing:.05em;opacity:.65;font-weight:400}
.cat .dot{display:inline-block;width:6px;height:6px;border-radius:50%;margin-right:5px;
vertical-align:1px}
#hint{position:absolute;left:50%;top:50%;transform:translate(-50%,-50%);
text-align:center;color:var(--mut);font-size:.88rem;max-width:380px}
#hint .btn{margin-top:.9rem;display:inline-block;pointer-events:auto}

/* ---------- side panel ---------- */
#panel{position:absolute;top:0;right:0;bottom:0;width:390px;background:var(--bg2);
border-left:1px solid var(--br);transform:translateX(100%);transition:transform .18s;
overflow-y:auto;z-index:15;padding:1.1rem}
#panel.on{transform:none}
#panel h2{font-size:1.02rem;margin:.2rem 0 .5rem;line-height:1.4}
.kindtag{display:inline-block;font-size:.62rem;letter-spacing:.1em;padding:2px 8px;
border-radius:99px;border:1px solid;margin-bottom:.6rem}
.meta{color:var(--mut);font-size:.78rem;margin-bottom:.8rem}
.body{font-size:.86rem;white-space:pre-wrap;color:#c8cfd7;
border-left:2px solid var(--br);padding-left:.8rem;margin:.7rem 0}
.simrow{display:flex;gap:.5rem;align-items:baseline;padding:.4rem 0;
border-bottom:1px solid var(--br);cursor:pointer;font-size:.82rem}
.simrow:hover{color:var(--acc)}
.simrow .s{color:var(--mut);font-size:.72rem;min-width:36px}
.close{position:absolute;top:.7rem;right:.8rem;cursor:pointer;color:var(--mut);
font-size:1.2rem;line-height:1}
.close:hover{color:var(--fg)}
h4{font-size:.7rem;letter-spacing:.13em;color:var(--mut);margin:1.3rem 0 .4rem;
font-weight:600}

/* ---------- forms ---------- */
input[type=text],textarea,#panel select{width:100%;background:var(--card);
border:1px solid var(--br);border-radius:8px;padding:.55rem .7rem;font-size:.86rem;
margin-bottom:.55rem}
input:focus,textarea:focus{outline:none;border-color:var(--acc)}
textarea{min-height:110px;resize:vertical;font-family:inherit}

/* ---------- discover ---------- */
#disc{padding:1.5rem;overflow-y:auto;height:100%}
.wrap{max-width:880px;margin:0 auto}
form.search{display:flex;gap:.5rem;margin-bottom:.9rem}
form.search input{margin:0}
.chips{display:flex;gap:.4rem;flex-wrap:wrap;margin-bottom:1.2rem}
.chip{background:var(--card);border:1px solid var(--br);border-radius:99px;
padding:.28rem .8rem;font-size:.78rem;cursor:pointer;color:var(--mut)}
.chip:hover{border-color:var(--acc);color:var(--fg)}
.row{display:flex;gap:.6rem;align-items:center;flex-wrap:wrap;margin-bottom:1.1rem;
font-size:.8rem;color:var(--mut)}
#status{min-height:1.4rem;font-size:.83rem;color:var(--mut);margin-bottom:.8rem}
.spin{display:inline-block;width:10px;height:10px;border:2px solid var(--br);
border-top-color:var(--acc);border-radius:50%;animation:sp .7s linear infinite;
margin-right:.45rem;vertical-align:-1px}
@keyframes sp{to{transform:rotate(360deg)}}
.card{background:var(--card);border:1px solid var(--br);border-radius:11px;
padding:.9rem 1.1rem;margin-bottom:.8rem}
.card h3{font-size:.97rem;margin:0 0 .35rem;line-height:1.45;font-weight:600}
.card h3 a{color:var(--fg);text-decoration:none}
.card h3 a:hover{color:var(--acc)}
.tag{display:inline-block;background:#1b202a;border:1px solid var(--br);border-radius:5px;
padding:1px 7px;margin-right:5px;font-size:.7rem;color:var(--mut)}
.tag.new{border-color:#2d5a3d;color:var(--ok)}
.abs{font-size:.83rem;color:var(--mut);max-height:4.2em;overflow:hidden;margin:.35rem 0}
.links a{color:var(--acc);text-decoration:none;font-size:.79rem;margin-right:.8rem}
.save{float:right;font-size:.75rem;padding:.2rem .6rem}
h2.topic{font-size:1rem;margin:1.8rem 0 .7rem;padding-bottom:.4rem;
border-bottom:1px solid var(--br)}
.empty{color:var(--mut);font-style:italic;font-size:.87rem}
.err{color:#fca5a5;background:#2a1518;border:1px solid #4c1d24;border-radius:8px;
padding:.75rem 1rem;font-size:.86rem}
#toast{position:fixed;bottom:1.2rem;left:50%;transform:translateX(-50%);
background:var(--card);border:1px solid var(--acc);border-radius:9px;
padding:.6rem 1.1rem;font-size:.85rem;opacity:0;transition:opacity .2s;
pointer-events:none;z-index:50}
#toast.on{opacity:1}
</style>

<div id="top">
  <span class="brand">JARVIS OS</span>
  <div class="tabs">
    <div class="tab on" data-v="brain">Brain</div>
    <div class="tab" data-v="disc">Discover</div>
  </div>
  <select id="ws" title="Workspace"></select>
  <button class="btn" id="newws" title="New workspace">+</button>
  <span class="sp"></span>
  <span class="stat" id="gstat"></span>
  <button class="btn" id="add">+ Note</button>
  <button class="btn" id="refresh" title="Recompute embeddings and links">Re-index</button>
</div>

<div id="main">
  <div class="view on" id="v-brain">
    <canvas id="cv"></canvas>
    <div id="cats"></div>
    <div id="hint" style="display:none">
      Your brain is empty.<br>Search papers in <b>Discover</b> and save them,
      or add your first note.
      <br><button class="btn" onclick="openEditor()">+ Add a note</button>
    </div>
  </div>

  <div class="view" id="v-disc">
    <div id="disc"><div class="wrap">
      <form class="search" id="f">
        <input type="text" id="q" placeholder="Type a research field, e.g. ECG arrhythmia transformer">
        <button class="btn pri" id="go">Search</button>
        <button type="button" class="btn" id="dg">Digest</button>
      </form>
      <div class="chips" id="chips"></div>
      <div class="row">
        <label>Window <select id="days">
          <option value="7">7 days</option><option value="30">30 days</option>
          <option value="90" selected>90 days</option><option value="365">1 year</option>
          <option value="0">any time</option></select></label>
        <label>Show <select id="top">
          <option>10</option><option selected>20</option><option>40</option></select></label>
        <label><input type="checkbox" id="onlynew" style="width:auto;margin:0"> only unseen</label>
      </div>
      <div id="status"></div>
      <div id="out"></div>
    </div></div>
  </div>
</div>

<div id="panel"><span class="close" onclick="closePanel()">&times;</span>
  <div id="pbody"></div>
</div>
<div id="toast"></div>

<script>
const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
const esc=s=>(s==null?'':String(s)).replace(/[&<>"']/g,c=>
  ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
let WS='default', GRAPH={nodes:[],links:[],categories:[]}, SEL=null, busy=false;
let CENT={};    // node id -> centrality, for the detail panel

function toast(m){const t=$('#toast');t.textContent=m;t.classList.add('on');
  clearTimeout(t._t);t._t=setTimeout(()=>t.classList.remove('on'),2200);}

async function api(path, body){
  const opt = body===undefined ? {} :
    {method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)};
  const r = await fetch(path,opt); const j = await r.json();
  if(!r.ok||j.error) throw new Error(j.error||('HTTP '+r.status));
  return j;
}

/* ================= tabs ================= */
$$('.tab').forEach(t=>t.addEventListener('click',()=>{
  $$('.tab').forEach(x=>x.classList.toggle('on',x===t));
  $$('.view').forEach(v=>v.classList.toggle('on', v.id==='v-'+t.dataset.v));
  if(t.dataset.v==='brain') resize();
}));

/* ================= force-directed graph ================= */
const cv=$('#cv'), ctx=cv.getContext('2d');
let W=0,H=0,DPR=1, cam={x:0,y:0,z:1}, drag=null, hover=null, nodes=[], edges=[], t0=0;

function resize(){
  DPR=Math.min(window.devicePixelRatio||1,2);
  W=cv.clientWidth; H=cv.clientHeight;
  cv.width=W*DPR; cv.height=H*DPR; ctx.setTransform(DPR,0,0,DPR,0,0);
  layoutCats();
}
window.addEventListener('resize',resize);

/* Radius encodes centrality: core knowledge sits in the middle, loosely
   related material drifts to the rim. maxR is recomputed on resize. */
let maxR=300;
function targetRadius(n){ return (1 - (n.centrality||0)) * maxR + 26; }

function seedLayout(){
  const cx=W/2, cy=H/2, nC=Math.max(1,GRAPH.clusters||1);
  maxR=Math.min(W,H)*0.40;
  nodes = GRAPH.nodes.map(n=>{
    // angle from the cluster (keeps topics apart), radius from centrality
    const a=(n.cluster/nC)*Math.PI*2 + (Math.random()-0.5)*0.8;
    const r=targetRadius(n);
    return {...n, x:cx+Math.cos(a)*r, y:cy+Math.sin(a)*r, vx:0, vy:0,
            r:4+Math.min(n.degree,8)*0.75+(n.centrality||0)*3};
  });
  const idx={}; nodes.forEach((n,i)=>idx[n.id]=i);
  edges = GRAPH.links.filter(l=>idx[l.s]!=null&&idx[l.t]!=null)
                     .map(l=>({a:idx[l.s], b:idx[l.t], w:l.w}));
}

function step(){
  const cx=W/2, cy=H/2, n=nodes.length;
  if(!n) return;
  // repulsion, O(n²) — fine up to a few hundred nodes
  for(let i=0;i<n;i++){
    const a=nodes[i];
    for(let j=i+1;j<n;j++){
      const b=nodes[j];
      let dx=b.x-a.x, dy=b.y-a.y, d2=dx*dx+dy*dy;
      if(d2<1) {dx=Math.random()-0.5; dy=Math.random()-0.5; d2=1;}
      if(d2>90000) continue;
      const f=900/d2, d=Math.sqrt(d2), fx=dx/d*f, fy=dy/d*f;
      a.vx-=fx; a.vy-=fy; b.vx+=fx; b.vy+=fy;
    }
    /* Radial constraint — this is what makes the picture readable.
       Instead of a plain pull toward the centre, each node is pulled toward
       ITS OWN target ring. Strong force so the ordering stays legible even
       while the spring layout is still settling. */
    const dx=a.x-cx, dy=a.y-cy, d=Math.hypot(dx,dy)||1;
    const want=targetRadius(a), err=d-want;
    a.vx-=dx/d*err*0.045;
    a.vy-=dy/d*err*0.045;
  }
  // springs along edges; stronger similarity pulls shorter
  for(const e of edges){
    const a=nodes[e.a], b=nodes[e.b];
    const dx=b.x-a.x, dy=b.y-a.y, d=Math.hypot(dx,dy)||1;
    const rest=110-70*Math.min(e.w*3,1);
    // tangential only would be ideal; a small factor keeps springs from
    // fighting the radial constraint and blurring the centrality ordering
    const f=(d-rest)*0.0035;
    const fx=dx/d*f, fy=dy/d*f;
    a.vx+=fx; a.vy+=fy; b.vx-=fx; b.vy-=fy;
  }
  for(const a of nodes){
    if(a===drag) continue;
    a.vx*=0.86; a.vy*=0.86;
    a.x+=Math.max(-8,Math.min(8,a.vx));
    a.y+=Math.max(-8,Math.min(8,a.vy));
  }
}

function toScreen(p){return {x:(p.x-W/2)*cam.z+W/2+cam.x, y:(p.y-H/2)*cam.z+H/2+cam.y};}
function fromScreen(x,y){return {x:(x-cam.x-W/2)/cam.z+W/2, y:(y-cam.y-H/2)/cam.z+H/2};}

function draw(ts){
  requestAnimationFrame(draw);
  if(!$('#v-brain').classList.contains('on')) return;
  if(!W) resize();
  step();
  ctx.clearRect(0,0,W,H);

  // background: glow at the core
  const g=ctx.createRadialGradient(W/2,H/2,0,W/2,H/2,Math.max(W,H)*0.6);
  g.addColorStop(0,'rgba(30,60,120,0.20)'); g.addColorStop(1,'rgba(0,0,0,0)');
  ctx.fillStyle=g; ctx.fillRect(0,0,W,H);

  // reference rings: give the eye a scale for "how central is this?"
  const c0=toScreen({x:W/2,y:H/2});
  ctx.setLineDash([2,6]); ctx.lineWidth=1;
  [['CORE',0.28],['',0.62],['PERIPHERY',1.0]].forEach(([lbl,f])=>{
    const rr=(f*maxR+26)*cam.z;
    ctx.strokeStyle='rgba(125,135,148,0.16)';
    ctx.beginPath(); ctx.arc(c0.x,c0.y,rr,0,7); ctx.stroke();
    if(lbl){
      ctx.setLineDash([]);
      ctx.fillStyle='rgba(125,135,148,0.42)';
      ctx.font='9px -apple-system,Segoe UI,sans-serif'; ctx.textAlign='center';
      ctx.fillText(lbl, c0.x, c0.y-rr-5);
      ctx.setLineDash([2,6]);
    }
  });
  ctx.setLineDash([]);

  // edges
  ctx.lineWidth=1;
  for(const e of edges){
    const a=toScreen(nodes[e.a]), b=toScreen(nodes[e.b]);
    const hot = hover && (nodes[e.a].id===hover.id||nodes[e.b].id===hover.id);
    ctx.strokeStyle = hot ? 'rgba(110,168,254,0.55)'
                          : 'rgba(110,168,254,'+(0.05+e.w*0.35)+')';
    ctx.beginPath(); ctx.moveTo(a.x,a.y); ctx.lineTo(b.x,b.y); ctx.stroke();
  }

  // nodes
  const pulse=0.5+0.5*Math.sin(ts/900);
  ctx.globalCompositeOperation='lighter';
  for(const nd of nodes){
    const p=toScreen(nd), r=nd.r*cam.z;
    const on = (hover&&hover.id===nd.id)||(SEL&&SEL.id===nd.id);
    // central nodes glow harder, rim nodes fade out — second visual cue
    // on top of distance, so the ranking survives even when zoomed in
    const c=nd.centrality||0;
    const hexA=x=>Math.round(Math.max(0,Math.min(255,x))).toString(16).padStart(2,'0');
    const gg=ctx.createRadialGradient(p.x,p.y,0,p.x,p.y,r*(on?6:4));
    gg.addColorStop(0, nd.color+hexA(90+c*130));
    gg.addColorStop(0.35, nd.color+hexA(on?110:(20+c*55)));
    gg.addColorStop(1, nd.color+'00');
    ctx.fillStyle=gg;
    ctx.beginPath(); ctx.arc(p.x,p.y,r*(on?6:4),0,7); ctx.fill();
  }
  ctx.globalCompositeOperation='source-over';
  for(const nd of nodes){
    const p=toScreen(nd), r=nd.r*cam.z;
    const on=(hover&&hover.id===nd.id)||(SEL&&SEL.id===nd.id);
    ctx.fillStyle = on ? '#fff' : nd.color;
    ctx.beginPath(); ctx.arc(p.x,p.y,r*(on?1.35:1)*(0.95+0.05*pulse),0,7); ctx.fill();
  }

  // labels: only the most central ones, plus whatever is hovered/selected
  ctx.font='11px -apple-system,Segoe UI,sans-serif'; ctx.textAlign='center';
  const labelled=new Set(nodes.slice(0,8).map(n=>n.id));   // sorted by centrality
  for(const nd of nodes){
    const on=(hover&&hover.id===nd.id)||(SEL&&SEL.id===nd.id);
    if(!on && !labelled.has(nd.id)) continue;
    const p=toScreen(nd);
    const txt=nd.title.length>34?nd.title.slice(0,33)+'…':nd.title;
    ctx.fillStyle= on ? '#fff'
      : 'rgba(230,232,235,'+(0.35+(nd.centrality||0)*0.5)+')';
    ctx.fillText(txt, p.x, p.y - nd.r*cam.z - 7);
  }
}

function pick(sx,sy){
  const w=fromScreen(sx,sy); let best=null,bd=1e9;
  for(const nd of nodes){
    const d=Math.hypot(nd.x-w.x, nd.y-w.y);
    if(d<Math.max(nd.r+8,14) && d<bd){bd=d;best=nd;}
  }
  return best;
}
cv.addEventListener('mousemove',e=>{
  const r=cv.getBoundingClientRect(), sx=e.clientX-r.left, sy=e.clientY-r.top;
  if(drag){ const w=fromScreen(sx,sy); drag.x=w.x; drag.y=w.y; drag.vx=drag.vy=0; return; }
  if(cam._pan){ cam.x=cam._px+(e.clientX-cam._sx); cam.y=cam._py+(e.clientY-cam._sy); return; }
  hover=pick(sx,sy); cv.style.cursor=hover?'pointer':'grab';
});
cv.addEventListener('mousedown',e=>{
  const r=cv.getBoundingClientRect(), n=pick(e.clientX-r.left,e.clientY-r.top);
  if(n) drag=n;
  else {cam._pan=true;cam._sx=e.clientX;cam._sy=e.clientY;cam._px=cam.x;cam._py=cam.y;}
});
window.addEventListener('mouseup',()=>{drag=null;cam._pan=false;});
cv.addEventListener('click',e=>{
  const r=cv.getBoundingClientRect(), n=pick(e.clientX-r.left,e.clientY-r.top);
  if(n) showNode(n.id);
});
cv.addEventListener('wheel',e=>{
  e.preventDefault();
  cam.z=Math.max(0.3,Math.min(3,cam.z*(e.deltaY<0?1.12:0.89)));
},{passive:false});

/* categories around the rim, control-panel style */
const CAT_POS=[[6,14],[6,42],[6,70],[80,14],[80,42],[80,70]];
function layoutCats(){
  const el=$('#cats'); if(!el) return;
  el.innerHTML=GRAPH.categories.map((c,i)=>{
    const [l,t]=CAT_POS[i%CAT_POS.length];
    return `<div class="cat" style="left:${l}%;top:${t}%">
      <span class="dot" style="background:${c.color}"></span>${esc(c.label)}
      <b>${c.count} node</b></div>`;
  }).join('');
}

/* ================= brain data ================= */
async function loadGraph(){
  GRAPH=await api('/api/graph?ws='+encodeURIComponent(WS));
  CENT={}; GRAPH.nodes.forEach(n=>CENT[n.id]=n.centrality);
  $('#gstat').textContent=`${GRAPH.nodes.length} nodes · ${GRAPH.links.length} links · ${GRAPH.model}`;
  $('#hint').style.display=GRAPH.nodes.length?'none':'block';
  seedLayout(); layoutCats();
}

async function showNode(id){
  const j=await api('/api/node?id='+encodeURIComponent(id));
  SEL=j.node;
  const n=j.node, c=n.color||'#6ea8fe';
  $('#pbody').innerHTML=`
    <span class="kindtag" style="color:${c};border-color:${c}">${esc(n.kind.toUpperCase())}</span>
    <h2>${esc(n.title)}</h2>
    <div class="meta">updated ${esc((n.updated||'').replace('T',' '))}
      ${n.meta&&n.meta.venue?' · '+esc(n.meta.venue):''}
      ${n.meta&&n.meta.citations?' · '+n.meta.citations+' cit':''}
      ${CENT[n.id]!=null?` · centrality ${(CENT[n.id]*100).toFixed(0)}%`:''}</div>
    ${n.body?`<div class="body">${esc(n.body)}</div>`:''}
    ${n.url?`<div class="links"><a href="${esc(n.url)}" target="_blank" rel="noopener">Open source</a></div>`:''}
    ${n.tag_list&&n.tag_list.length?`<div style="margin-top:.5rem">${n.tag_list.map(t=>`<span class="tag">${esc(t)}</span>`).join('')}</div>`:''}
    <h4>SEMANTICALLY RELATED</h4>
    ${j.similar.length?j.similar.map(s=>`<div class="simrow" onclick="showNode('${s.id}')">
        <span class="s">${s.similarity.toFixed(2)}</span>
        <span>${esc(s.title)}</span></div>`).join('')
      :'<div class="empty">Nothing related yet — add more notes.</div>'}
    <h4>ACTIONS</h4>
    <button class="btn" onclick="openEditor(SEL)">Edit</button>
    <button class="btn" onclick="delNode('${n.id}')" style="border-color:#4c1d24;color:#fca5a5">Delete</button>`;
  $('#panel').classList.add('on');
}
function closePanel(){$('#panel').classList.remove('on');SEL=null;}

function openEditor(n){
  n=n||{};
  $('#pbody').innerHTML=`
    <h2>${n.id?'Edit node':'New node'}</h2>
    <select id="e-kind">
      ${['note','concept','goal','journal','highlight'].map(k=>
        `<option ${n.kind===k?'selected':''}>${k}</option>`).join('')}
    </select>
    <input type="text" id="e-title" placeholder="Title" value="${esc(n.title||'')}">
    <textarea id="e-body" placeholder="Body — what you want to remember">${esc(n.body||'')}</textarea>
    <input type="text" id="e-tags" placeholder="tags, comma, separated" value="${esc(n.tags||'')}">
    <button class="btn pri" onclick="saveNode('${n.id||''}')">Save</button>
    <button class="btn" onclick="closePanel()">Cancel</button>`;
  $('#panel').classList.add('on');
  $('#e-title').focus();
}

async function saveNode(id){
  const t=$('#e-title').value.trim();
  if(!t){toast('Title is required');return;}
  await api('/api/node/save',{id:id||null, ws:WS, kind:$('#e-kind').value,
    title:t, body:$('#e-body').value, tags:$('#e-tags').value});
  closePanel(); toast('Saved'); await reindexAndReload();
}
async function delNode(id){
  if(!confirm('Delete this node?'))return;
  await api('/api/node/delete',{id}); closePanel(); toast('Deleted');
  await reindexAndReload();
}
async function reindexAndReload(){
  await api('/api/brain/refresh',{ws:WS}); await loadGraph();
}

/* ================= workspaces ================= */
async function loadWs(){
  const j=await api('/api/workspaces');
  $('#ws').innerHTML=j.workspaces.map(w=>
    `<option value="${esc(w.id)}" ${w.id===WS?'selected':''}>${esc(w.name)} (${w.n_nodes})</option>`).join('');
}
$('#ws').addEventListener('change',async e=>{WS=e.target.value;await loadGraph();});
$('#newws').addEventListener('click',async()=>{
  const name=prompt('Workspace name:'); if(!name)return;
  const j=await api('/api/workspace/new',{name}); WS=j.id;
  await loadWs(); await loadGraph(); toast('Workspace created');
});
$('#add').addEventListener('click',()=>openEditor());
$('#refresh').addEventListener('click',async()=>{
  toast('Re-indexing…'); const j=await api('/api/brain/refresh',{ws:WS});
  await loadGraph(); toast(`Indexed ${j.indexed}, ${j.links} links, ${j.model}`);
});

/* ================= discover ================= */
function card(p){
  const links=[];
  if(p.url) links.push(`<a href="${esc(p.url)}" target="_blank" rel="noopener">Page</a>`);
  if(p.pdf_url) links.push(`<a href="${esc(p.pdf_url)}" target="_blank" rel="noopener">PDF</a>`);
  if(p.doi) links.push(`<a href="https://doi.org/${esc(p.doi)}" target="_blank" rel="noopener">DOI</a>`);
  const body=p.summary?`<div class="body">${esc(p.summary)}</div>`
    :(p.abstract?`<div class="abs">${esc(p.abstract.slice(0,320))}…</div>`:'');
  return `<div class="card">
    <button class="btn save" onclick='savePaper(${JSON.stringify(JSON.stringify(p))})'>+ Brain</button>
    <h3><a href="${esc(p.url)}" target="_blank" rel="noopener">${esc(p.title)}</a></h3>
    <div class="meta" style="font-size:.78rem;color:var(--mut)">${esc(p.published||'n/a')} · ${esc(p.authors_short||'')} · ${esc(p.venue||'n/a')}</div>
    <div>${p.is_new?'<span class="tag new">NEW</span>':''}<span class="tag">${p.citations} cit</span>
      <span class="tag">score ${p.score}</span><span class="tag">${esc(p.source)}</span></div>
    ${body}<div class="links">${links.join('')}</div></div>`;
}
function render(groups){
  $('#out').innerHTML=Object.entries(groups).map(([k,v])=>
    (Object.keys(groups).length>1?`<h2 class="topic">${esc(k)} <span style="color:var(--mut);font-size:.8rem">${v.length}</span></h2>`:'')
    +(v.length?v.map(card).join(''):'<div class="empty">Nothing found.</div>')).join('');
}
async function savePaper(js){
  await api('/api/brain/save_paper',{ws:WS, paper:JSON.parse(js)});
  toast('Saved to brain'); await reindexAndReload(); await loadWs();
}
function setBusy(b,m){busy=b;$('#go').disabled=b;$('#dg').disabled=b;
  $('#status').innerHTML=b?'<span class="spin"></span>'+esc(m):esc(m||'');}

$('#f').addEventListener('submit',async e=>{
  e.preventDefault(); const q=$('#q').value.trim(); if(!q||busy)return;
  setBusy(true,'Searching "'+q+'" across all sources…'); const t=Date.now();
  try{
    const j=await api('/api/search',{query:q,days:+$('#days').value,
      top:+$('#top').value,only_new:$('#onlynew').checked});
    render({[q]:j.papers});
    setBusy(false,`${j.papers.length} papers · ${j.raw} raw → ${j.unique} after dedupe · ${((Date.now()-t)/1000).toFixed(1)}s`);
  }catch(err){setBusy(false,'');$('#out').innerHTML=`<div class="err">${esc(err.message)}</div>`;}
});
$('#dg').addEventListener('click',async()=>{
  if(busy)return; setBusy(true,'Scanning all topics for unseen papers…'); const t=Date.now();
  try{
    const j=await api('/api/digest',{days:+$('#days').value});
    render(j.groups);
    const n=Object.values(j.groups).reduce((a,b)=>a+b.length,0);
    setBusy(false,`${n} new papers · ${((Date.now()-t)/1000).toFixed(1)}s`);
  }catch(err){setBusy(false,'');$('#out').innerHTML=`<div class="err">${esc(err.message)}</div>`;}
});

/* ================= boot ================= */
async function init(){
  try{
    const j=await api('/api/presets');
    $('#chips').innerHTML=j.chips.map(c=>`<span class="chip" data-q="${esc(c.query)}">${esc(c.label)}</span>`).join('');
    $$('.chip').forEach(el=>el.addEventListener('click',()=>{
      $('#q').value=el.dataset.q; $('#f').dispatchEvent(new Event('submit'));}));
  }catch(e){}
  await loadWs(); await loadGraph();
  resize(); requestAnimationFrame(draw);
}
init();
</script>
</html>"""
