"""Jarvis persistence: SQLite record of every paper already seen.

That is what lets a later run report only NEW papers instead of repeating
itself. The DB lives in the install folder (E:\\Jarvis\\data\\jarvis.db).
"""

from __future__ import annotations

import hashlib
import json
import logging
import re
import sqlite3
import uuid
from contextlib import closing
from datetime import date, datetime
from pathlib import Path

from .models import Paper

log = logging.getLogger("jarvis.store")

SCHEMA = """
CREATE TABLE IF NOT EXISTS seen (
    key         TEXT PRIMARY KEY,
    title       TEXT NOT NULL,
    doi         TEXT,
    url         TEXT,
    published   TEXT,
    venue       TEXT,
    citations   INTEGER DEFAULT 0,
    source      TEXT,
    score       REAL,
    topic       TEXT,
    summary  TEXT,
    first_seen  TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_seen_topic     ON seen(topic);
CREATE INDEX IF NOT EXISTS idx_seen_first     ON seen(first_seen);
CREATE INDEX IF NOT EXISTS idx_seen_published ON seen(published);

CREATE TABLE IF NOT EXISTS runs (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    topic      TEXT,
    query      TEXT,
    ran_at     TEXT,
    n_found    INTEGER,
    n_new      INTEGER,
    report     TEXT
);

-- ===================== SECOND BRAIN =====================
-- Everything is a node in one graph: saved papers, notes, goals, journal
-- entries, concepts, highlights. One embedding and graph pipeline serves them
-- all instead of a separate path per type.

CREATE TABLE IF NOT EXISTS workspaces (
    id      TEXT PRIMARY KEY,
    name    TEXT NOT NULL,
    created TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS nodes (
    id         TEXT PRIMARY KEY,
    workspace  TEXT NOT NULL DEFAULT 'default',
    kind       TEXT NOT NULL,          -- paper|note|goal|journal|concept|highlight
    title      TEXT NOT NULL,
    body       TEXT DEFAULT '',
    tags       TEXT DEFAULT '',        -- comma separated
    url        TEXT DEFAULT '',
    meta       TEXT DEFAULT '{}',      -- free-form JSON (authors, doi, venue...)
    paper_key  TEXT,                   -- points at seen.key when the node is a paper
    status     TEXT DEFAULT '',        -- for goals: open|done
    created    TEXT NOT NULL,
    updated    TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_nodes_ws     ON nodes(workspace);
CREATE INDEX IF NOT EXISTS idx_nodes_kind   ON nodes(workspace, kind);
CREATE INDEX IF NOT EXISTS idx_nodes_paper  ON nodes(paper_key);
CREATE UNIQUE INDEX IF NOT EXISTS idx_nodes_ws_paper
    ON nodes(workspace, paper_key) WHERE paper_key IS NOT NULL;

CREATE TABLE IF NOT EXISTS links (
    src    TEXT NOT NULL,
    dst    TEXT NOT NULL,
    kind   TEXT NOT NULL DEFAULT 'related',   -- related|manual|cites|author
    weight REAL NOT NULL DEFAULT 1.0,
    PRIMARY KEY (src, dst, kind)
);
CREATE INDEX IF NOT EXISTS idx_links_src ON links(src);
CREATE INDEX IF NOT EXISTS idx_links_dst ON links(dst);

CREATE TABLE IF NOT EXISTS vectors (
    node_id  TEXT PRIMARY KEY,
    model    TEXT NOT NULL,
    dim      INTEGER NOT NULL,
    data     BLOB NOT NULL,
    fp       TEXT NOT NULL,            -- content fingerprint: re-embed only on change
    updated  TEXT NOT NULL
);
"""

KINDS = ("paper", "note", "goal", "journal", "concept", "highlight")


class Store:
    def __init__(self, path: str | Path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with closing(self._conn()) as c:
            c.executescript(SCHEMA)
            c.commit()
            self._migrate(c)

    def _conn(self) -> sqlite3.Connection:
        c = sqlite3.connect(self.path, timeout=30)
        c.row_factory = sqlite3.Row
        return c

    # ---- migrations -----------------------------------------------------

    @staticmethod
    def _columns(c: sqlite3.Connection, table: str) -> set[str]:
        try:
            return {r["name"] for r in c.execute(f"PRAGMA table_info({table})")}
        except sqlite3.Error:
            return set()

    def _migrate(self, c: sqlite3.Connection) -> None:
        """Bring an older database up to the current schema.

        CREATE TABLE IF NOT EXISTS silently does nothing when the table already
        exists, so a renamed or added column never reaches an existing install.
        Without this, upgrading raises
        "OperationalError: table seen has no column named summary".
        Every step is idempotent and safe to run on a fresh DB.
        """
        changed = False

        # 1.x -> 2.0: the summary column stopped being Vietnamese-specific
        cols = self._columns(c, "seen")
        if cols and "summary" not in cols:
            if "summary_vi" in cols:
                try:
                    c.execute("ALTER TABLE seen RENAME COLUMN summary_vi TO summary")
                    log.info("migrated: seen.summary_vi -> seen.summary")
                except sqlite3.Error:
                    # RENAME COLUMN needs SQLite 3.25+; copy across instead
                    c.execute("ALTER TABLE seen ADD COLUMN summary TEXT")
                    c.execute("UPDATE seen SET summary = summary_vi")
                    log.info("migrated: copied seen.summary_vi into seen.summary")
            else:
                c.execute("ALTER TABLE seen ADD COLUMN summary TEXT")
                log.info("migrated: added seen.summary")
            changed = True

        # generic backfill for any other column added in a later version
        expected = {
            "seen": {"key": "TEXT", "title": "TEXT", "doi": "TEXT", "url": "TEXT",
                     "published": "TEXT", "venue": "TEXT", "citations": "INTEGER",
                     "source": "TEXT", "score": "REAL", "topic": "TEXT",
                     "summary": "TEXT", "first_seen": "TEXT"},
            "nodes": {"id": "TEXT", "workspace": "TEXT", "kind": "TEXT",
                      "title": "TEXT", "body": "TEXT", "tags": "TEXT",
                      "url": "TEXT", "meta": "TEXT", "paper_key": "TEXT",
                      "status": "TEXT", "created": "TEXT", "updated": "TEXT"},
        }
        for table, want in expected.items():
            have = self._columns(c, table)
            if not have:
                continue
            for col, typ in want.items():
                if col not in have:
                    c.execute(f"ALTER TABLE {table} ADD COLUMN {col} {typ}")
                    log.info("migrated: added %s.%s", table, col)
                    changed = True

        if changed:
            c.commit()

    # ---- new-paper filtering -------------------------------------------

    def filter_new(self, papers: list[Paper]) -> list[Paper]:
        """Return papers never seen before. Writes nothing; use mark_seen for that."""
        if not papers:
            return []
        keys = [p.key for p in papers]
        with closing(self._conn()) as c:
            qs = ",".join("?" * len(keys))
            rows = c.execute(f"SELECT key FROM seen WHERE key IN ({qs})", keys).fetchall()
        known = {r["key"] for r in rows}
        return [p for p in papers if p.key not in known]

    def mark_seen(self, papers: list[Paper], topic: str = "") -> int:
        """Record papers as seen. Returns how many rows were actually inserted."""
        if not papers:
            return 0
        now = datetime.now().isoformat(timespec="seconds")
        rows = [(
            p.key, p.title, p.doi, p.url,
            p.published.isoformat() if p.published else None,
            p.venue, p.citations, p.source, p.score, topic, p.summary, now,
        ) for p in papers]
        with closing(self._conn()) as c:
            before = c.execute("SELECT COUNT(*) n FROM seen").fetchone()["n"]
            c.executemany(
                "INSERT OR IGNORE INTO seen (key,title,doi,url,published,venue,"
                "citations,source,score,topic,summary,first_seen) "
                "VALUES (?,?,?,?,?,?,?,?,?,?,?,?)", rows)
            c.commit()
            after = c.execute("SELECT COUNT(*) n FROM seen").fetchone()["n"]
        return after - before

    # ---- run log --------------------------------------------------------

    def log_run(self, topic: str, query: str, n_found: int, n_new: int,
                report: str = "") -> None:
        with closing(self._conn()) as c:
            c.execute("INSERT INTO runs (topic,query,ran_at,n_found,n_new,report) "
                      "VALUES (?,?,?,?,?,?)",
                      (topic, query, datetime.now().isoformat(timespec="seconds"),
                       n_found, n_new, report))
            c.commit()

    # ---- queries --------------------------------------------------------

    def stats(self) -> dict:
        with closing(self._conn()) as c:
            total = c.execute("SELECT COUNT(*) n FROM seen").fetchone()["n"]
            by_topic = {r["topic"]: r["n"] for r in c.execute(
                "SELECT topic, COUNT(*) n FROM seen GROUP BY topic ORDER BY n DESC")}
            runs = c.execute("SELECT COUNT(*) n FROM runs").fetchone()["n"]
            last = c.execute("SELECT ran_at FROM runs ORDER BY id DESC LIMIT 1").fetchone()
        return {"total_papers": total, "by_topic": by_topic,
                "total_runs": runs, "last_run": last["ran_at"] if last else None}

    def recent(self, days: int = 7, topic: str | None = None, limit: int = 100) -> list[dict]:
        cutoff = (datetime.now().timestamp() - days * 86400)
        cutoff_iso = datetime.fromtimestamp(cutoff).isoformat(timespec="seconds")
        sql = "SELECT * FROM seen WHERE first_seen >= ?"
        args: list = [cutoff_iso]
        if topic:
            sql += " AND topic = ?"
            args.append(topic)
        sql += " ORDER BY score DESC LIMIT ?"
        args.append(limit)
        with closing(self._conn()) as c:
            return [dict(r) for r in c.execute(sql, args)]

    def export_json(self, out: Path) -> Path:
        with closing(self._conn()) as c:
            rows = [dict(r) for r in c.execute("SELECT * FROM seen ORDER BY first_seen DESC")]
        out.write_text(json.dumps(rows, ensure_ascii=False, indent=2), encoding="utf-8")
        return out

    def purge_older_than(self, days: int) -> int:
        """Drop old rows so the DB does not grow forever."""
        cutoff = date.fromtimestamp(datetime.now().timestamp() - days * 86400).isoformat()
        with closing(self._conn()) as c:
            cur = c.execute("DELETE FROM seen WHERE first_seen < ?", (cutoff,))
            c.commit()
            return cur.rowcount

    # ================================================================
    #                        SECOND BRAIN
    # ================================================================

    # ---- workspaces ---------------------------------------------------

    def ensure_workspace(self, name: str = "default") -> str:
        wid = _slug(name)
        with closing(self._conn()) as c:
            c.execute("INSERT OR IGNORE INTO workspaces (id,name,created) VALUES (?,?,?)",
                      (wid, name, _now()))
            c.commit()
        return wid

    def workspaces(self) -> list[dict]:
        with closing(self._conn()) as c:
            rows = [dict(r) for r in c.execute(
                "SELECT w.id, w.name, w.created, "
                "(SELECT COUNT(*) FROM nodes n WHERE n.workspace = w.id) AS n_nodes "
                "FROM workspaces w ORDER BY w.created")]
        if not rows:
            self.ensure_workspace("default")
            return [{"id": "default", "name": "default", "created": _now(), "n_nodes": 0}]
        return rows

    def rename_workspace(self, wid: str, new_name: str) -> None:
        with closing(self._conn()) as c:
            c.execute("UPDATE workspaces SET name=? WHERE id=?", (new_name, wid))
            c.commit()

    # ---- nodes --------------------------------------------------------

    def upsert_node(self, *, kind: str, title: str, body: str = "",
                    tags: str = "", url: str = "", meta: dict | None = None,
                    paper_key: str | None = None, status: str = "",
                    workspace: str = "default", node_id: str | None = None) -> str:
        """Create or update a node. Returns its id.

        Paper nodes are deduplicated on (workspace, paper_key), so saving the
        same paper twice updates it instead of creating a copy.
        """
        if kind not in KINDS:
            raise ValueError(f"invalid kind: {kind} (allowed: {', '.join(KINDS)})")
        if not title.strip():
            raise ValueError("title must not be empty")

        now = _now()
        meta_s = json.dumps(meta or {}, ensure_ascii=False)

        with closing(self._conn()) as c:
            existing = None
            if node_id:
                existing = c.execute("SELECT id FROM nodes WHERE id=?", (node_id,)).fetchone()
            elif paper_key:
                existing = c.execute(
                    "SELECT id FROM nodes WHERE workspace=? AND paper_key=?",
                    (workspace, paper_key)).fetchone()

            if existing:
                nid = existing["id"]
                c.execute(
                    "UPDATE nodes SET kind=?,title=?,body=?,tags=?,url=?,meta=?,"
                    "status=?,updated=? WHERE id=?",
                    (kind, title, body, tags, url, meta_s, status, now, nid))
            else:
                nid = node_id or _new_id(kind)
                c.execute(
                    "INSERT INTO nodes (id,workspace,kind,title,body,tags,url,meta,"
                    "paper_key,status,created,updated) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",
                    (nid, workspace, kind, title, body, tags, url, meta_s,
                     paper_key, status, now, now))
            c.commit()
        return nid

    def get_node(self, node_id: str) -> dict | None:
        with closing(self._conn()) as c:
            r = c.execute("SELECT * FROM nodes WHERE id=?", (node_id,)).fetchone()
        return _node_row(r) if r else None

    def list_nodes(self, workspace: str = "default", kind: str | None = None,
                   query: str | None = None, limit: int = 2000) -> list[dict]:
        sql = "SELECT * FROM nodes WHERE workspace=?"
        args: list = [workspace]
        if kind:
            sql += " AND kind=?"
            args.append(kind)
        if query:
            sql += " AND (title LIKE ? OR body LIKE ? OR tags LIKE ?)"
            like = f"%{query}%"
            args += [like, like, like]
        sql += " ORDER BY updated DESC LIMIT ?"
        args.append(limit)
        with closing(self._conn()) as c:
            return [_node_row(r) for r in c.execute(sql, args)]

    def delete_node(self, node_id: str) -> bool:
        with closing(self._conn()) as c:
            cur = c.execute("DELETE FROM nodes WHERE id=?", (node_id,))
            c.execute("DELETE FROM links WHERE src=? OR dst=?", (node_id, node_id))
            c.execute("DELETE FROM vectors WHERE node_id=?", (node_id,))
            c.commit()
            return cur.rowcount > 0

    def counts_by_kind(self, workspace: str = "default") -> dict[str, int]:
        with closing(self._conn()) as c:
            rows = c.execute("SELECT kind, COUNT(*) n FROM nodes WHERE workspace=? "
                             "GROUP BY kind", (workspace,)).fetchall()
        out = {k: 0 for k in KINDS}
        out.update({r["kind"]: r["n"] for r in rows})
        return out

    # ---- links --------------------------------------------------------

    def set_links(self, edges: list[tuple[str, str, float]], kind: str = "related",
                  replace: bool = True) -> int:
        """Write edges. replace=True clears same-kind edges first (used by kNN)."""
        with closing(self._conn()) as c:
            if replace:
                c.execute("DELETE FROM links WHERE kind=?", (kind,))
            c.executemany(
                "INSERT OR REPLACE INTO links (src,dst,kind,weight) VALUES (?,?,?,?)",
                [(a, b, kind, w) for a, b, w in edges])
            c.commit()
        return len(edges)

    def add_link(self, src: str, dst: str, kind: str = "manual",
                 weight: float = 1.0) -> None:
        with closing(self._conn()) as c:
            c.execute("INSERT OR REPLACE INTO links (src,dst,kind,weight) VALUES (?,?,?,?)",
                      (src, dst, kind, weight))
            c.commit()

    def links(self, workspace: str = "default") -> list[dict]:
        with closing(self._conn()) as c:
            rows = c.execute(
                "SELECT l.* FROM links l "
                "JOIN nodes a ON a.id = l.src JOIN nodes b ON b.id = l.dst "
                "WHERE a.workspace=? AND b.workspace=?", (workspace, workspace)).fetchall()
        return [dict(r) for r in rows]

    # ---- vectors ------------------------------------------------------

    def get_vectors(self, workspace: str = "default") -> dict[str, list[float]]:
        from .embed import from_blob
        with closing(self._conn()) as c:
            rows = c.execute(
                "SELECT v.node_id, v.data FROM vectors v "
                "JOIN nodes n ON n.id = v.node_id WHERE n.workspace=?",
                (workspace,)).fetchall()
        return {r["node_id"]: from_blob(r["data"]) for r in rows}

    def get_fingerprints(self) -> dict[str, str]:
        with closing(self._conn()) as c:
            return {r["node_id"]: r["fp"] for r in c.execute(
                "SELECT node_id, fp FROM vectors")}

    def put_vectors(self, items: list[tuple[str, list[float], str]], model: str) -> int:
        """items = [(node_id, vector, fingerprint)]"""
        from .embed import to_blob
        now = _now()
        rows = [(nid, model, len(vec), to_blob(vec), fp, now) for nid, vec, fp in items]
        with closing(self._conn()) as c:
            c.executemany("INSERT OR REPLACE INTO vectors "
                          "(node_id,model,dim,data,fp,updated) VALUES (?,?,?,?,?,?)", rows)
            c.commit()
        return len(rows)

    def clear_vectors(self) -> None:
        with closing(self._conn()) as c:
            c.execute("DELETE FROM vectors")
            c.commit()


# ---------------------------------------------------------------- helpers


def _now() -> str:
    return datetime.now().isoformat(timespec="seconds")


def _slug(s: str) -> str:
    out = "".join(ch if ch.isalnum() else "-" for ch in s.lower()).strip("-")
    return re.sub(r"-+", "-", out) or "default"


_counter = 0


def _new_id(kind: str) -> str:
    global _counter
    _counter += 1
    return f"{kind[:2]}_{uuid.uuid4().hex[:10]}{_counter % 100:02d}"


def _node_row(r) -> dict:
    d = dict(r)
    try:
        d["meta"] = json.loads(d.get("meta") or "{}")
    except (ValueError, TypeError):
        d["meta"] = {}
    d["tag_list"] = [t.strip() for t in (d.get("tags") or "").split(",") if t.strip()]
    return d


def node_text(node: dict) -> str:
    """Text fed to the embedder. Title is repeated so it outweighs the body."""
    parts = [node.get("title", ""), node.get("title", ""),
             node.get("body", ""), node.get("tags", "")]
    meta = node.get("meta") or {}
    for key in ("venue", "authors", "abstract"):
        v = meta.get(key)
        if isinstance(v, list):
            v = " ".join(map(str, v))
        if v:
            parts.append(str(v))
    return " ".join(p for p in parts if p)


def fingerprint(node: dict) -> str:
    """Content changes -> fingerprint changes -> embedding is recomputed."""
    return hashlib.blake2b(node_text(node).encode("utf-8"),
                           digest_size=12).hexdigest()
