"""Second brain: embedding index, semantic graph, similarity search.

Bridges `store` (persistence) and `web` (UI).

Layout contract with the UI: every node carries a `centrality` in [0,1].
1.0 means "strongly tied to the rest of your knowledge" and the UI draws it near
the middle; 0.0 means "loosely related outlier" and it sits on the outer rim.
"""

from __future__ import annotations

import logging

from . import embed
from .models import Paper
from .store import KINDS, Store, fingerprint, node_text

log = logging.getLogger("jarvis.brain")

# display label + colour per node kind
KIND_META = {
    "paper":     {"label": "PAPERS",     "color": "#6ea8fe"},
    "note":      {"label": "NOTES",      "color": "#4ade80"},
    "concept":   {"label": "CONCEPTS",   "color": "#c084fc"},
    "goal":      {"label": "GOALS",      "color": "#fbbf24"},
    "journal":   {"label": "JOURNAL",    "color": "#f472b6"},
    "highlight": {"label": "HIGHLIGHTS", "color": "#22d3ee"},
}


class Brain:
    def __init__(self, store: Store, model_name: str | None = None):
        self.store = store
        self.model_name = model_name or "hashing"
        self._embedder = None

    # ---- lazily built embedder ----------------------------------------

    def embedder(self, corpus: list[str] | None = None):
        if self._embedder is None:
            self._embedder = embed.get_embedder(self.model_name, corpus)
        return self._embedder

    @property
    def backend_name(self) -> str:
        return getattr(self._embedder, "name", self.model_name)

    # ---- saving papers into the brain ---------------------------------

    def save_paper(self, p: Paper, workspace: str = "default",
                   tags: str = "") -> str:
        meta = {
            "authors": p.authors[:12],
            "venue": p.venue,
            "doi": p.doi,
            "citations": p.citations,
            "source": p.source,
            "published": p.published.isoformat() if p.published else None,
            "abstract": p.abstract[:3000],
            "pdf_url": p.pdf_url,
        }
        return self.store.upsert_node(
            kind="paper", title=p.title, body=p.abstract[:3000], tags=tags,
            url=p.url, meta=meta, paper_key=p.key, workspace=workspace)

    # ---- indexing ------------------------------------------------------

    def reindex(self, workspace: str = "default", force: bool = False) -> dict:
        """Embed nodes that are new or whose text changed.

        A content fingerprint lets us skip untouched nodes, so re-running this
        after adding one note costs almost nothing.
        """
        nodes = self.store.list_nodes(workspace)
        if not nodes:
            return {"indexed": 0, "skipped": 0, "total": 0, "model": self.model_name}

        corpus = [node_text(n) for n in nodes]
        emb = self.embedder(corpus)

        # The fallback backend learns IDF from the corpus itself, so when the
        # document set changes size the old vectors were built against a
        # different IDF and are no longer comparable. Only then rebuild all.
        if getattr(emb, "name", "") == "hashing-tfidf":
            if emb.n_docs != len(corpus):
                emb.fit(corpus)
                force = True

        old_fp = {} if force else self.store.get_fingerprints()
        todo = [(n, t) for n, t in zip(nodes, corpus)
                if old_fp.get(n["id"]) != fingerprint(n)]

        if todo:
            vecs = emb.encode([t for _, t in todo])
            self.store.put_vectors(
                [(n["id"], v, fingerprint(n)) for (n, _), v in zip(todo, vecs)],
                model=getattr(emb, "name", self.model_name))

        log.info("reindex: %d of %d nodes", len(todo), len(nodes))
        return {"indexed": len(todo), "skipped": len(nodes) - len(todo),
                "total": len(nodes), "model": getattr(emb, "name", self.model_name)}

    def rebuild_links(self, workspace: str = "default", k: int = 5,
                      min_sim: float | None = None) -> int:
        """Build kNN edges with an ADAPTIVE threshold.

        A fixed threshold does not work: hashing TF-IDF similarities live around
        0.1-0.25 while sentence-transformers sit around 0.5-0.9. One constant
        would yield an empty graph on one backend and a hairball on the other.
        So we walk the threshold down until edge density is reasonable.
        """
        vectors = self.store.get_vectors(workspace)
        n = len(vectors)
        if n < 2:
            self.store.set_links([], kind="related")
            return 0

        target = max(n - 1, int(n * 1.5))
        ladder = [min_sim] if min_sim is not None else [0.45, 0.30, 0.20, 0.14, 0.10,
                                                        0.07, 0.04, 0.02, 0.0]
        edges: list = []
        for thr in ladder:
            edges = embed.knn(vectors, k=k, min_sim=thr)
            if len(edges) >= target:
                log.info("threshold %.2f -> %d edges (target %d)", thr, len(edges), target)
                break

        self.store.set_links(edges, kind="related", replace=True)
        log.info("built %d semantic links across %d nodes", len(edges), n)
        return len(edges)

    def refresh(self, workspace: str = "default") -> dict:
        r = self.reindex(workspace)
        r["links"] = self.rebuild_links(workspace)
        return r

    # ---- semantic search ------------------------------------------------

    def search(self, query: str, workspace: str = "default",
               top: int = 20) -> list[dict]:
        vectors = self.store.get_vectors(workspace)
        if not vectors:
            return []
        emb = self.embedder()
        qv = emb.encode_one(query)
        hits = embed.most_similar(qv, vectors, top=top)
        by_id = {n["id"]: n for n in self.store.list_nodes(workspace)}
        out = []
        for nid, sim in hits:
            n = by_id.get(nid)
            if n and sim > 0.02:
                n = dict(n)
                n["similarity"] = sim
                out.append(n)
        return out

    def similar_to(self, node_id: str, workspace: str = "default",
                   top: int = 8) -> list[dict]:
        vectors = self.store.get_vectors(workspace)
        if node_id not in vectors:
            return []
        hits = embed.most_similar(vectors[node_id], vectors, top=top + 1,
                                  exclude={node_id})
        by_id = {n["id"]: n for n in self.store.list_nodes(workspace)}
        out = []
        for nid, sim in hits[:top]:
            n = by_id.get(nid)
            if n:
                n = dict(n)
                n["similarity"] = sim
                out.append(n)
        return out

    # ---- centrality -----------------------------------------------------

    @staticmethod
    def _centrality(node_ids: list[str], links: list[dict]) -> dict[str, float]:
        """How tied each node is to the rest of the brain, normalised to [0,1].

        Score = sum of incident edge weights. Summing weights rather than
        counting edges matters: three weak links should not outrank one very
        strong one, and this is exactly what the user reads off the radius.
        """
        raw = {nid: 0.0 for nid in node_ids}
        for l in links:
            w = float(l.get("weight") or 0.0)
            if l["src"] in raw:
                raw[l["src"]] += w
            if l["dst"] in raw:
                raw[l["dst"]] += w
        if not raw:
            return {}
        lo, hi = min(raw.values()), max(raw.values())
        if hi - lo < 1e-9:
            return {nid: 0.5 for nid in raw}
        return {nid: (v - lo) / (hi - lo) for nid, v in raw.items()}

    # ---- payload for the UI ---------------------------------------------

    def graph(self, workspace: str = "default", clusters: int = 6) -> dict:
        nodes = self.store.list_nodes(workspace)
        vectors = self.store.get_vectors(workspace)
        links = self.store.links(workspace)

        assign = embed.kmeans(vectors, k=clusters) if len(vectors) >= 2 else {}

        degree: dict[str, int] = {}
        for l in links:
            degree[l["src"]] = degree.get(l["src"], 0) + 1
            degree[l["dst"]] = degree.get(l["dst"], 0) + 1

        cent = self._centrality([n["id"] for n in nodes], links)

        payload_nodes = []
        for n in nodes:
            meta = n.get("meta") or {}
            payload_nodes.append({
                "id": n["id"],
                "kind": n["kind"],
                "title": n["title"],
                "snippet": (n.get("body") or "")[:220],
                "tags": n.get("tag_list", []),
                "url": n.get("url", ""),
                "status": n.get("status", ""),
                "updated": n.get("updated", ""),
                "cluster": assign.get(n["id"], 0),
                "degree": degree.get(n["id"], 0),
                # 1 = core of your knowledge, 0 = loosely related outlier.
                # The UI turns this straight into distance from the centre.
                "centrality": round(cent.get(n["id"], 0.0), 4),
                "color": KIND_META.get(n["kind"], {}).get("color", "#9aa3ad"),
                "citations": meta.get("citations", 0),
                "venue": meta.get("venue", ""),
                "published": meta.get("published"),
            })

        # most central first, so the UI can label the top ones without overlap
        payload_nodes.sort(key=lambda n: -n["centrality"])

        counts = self.store.counts_by_kind(workspace)
        categories = [{"kind": k,
                       "label": KIND_META.get(k, {}).get("label", k.upper()),
                       "color": KIND_META.get(k, {}).get("color", "#9aa3ad"),
                       "count": counts.get(k, 0)}
                      for k in KINDS]

        return {
            "workspace": workspace,
            "nodes": payload_nodes,
            "links": [{"s": l["src"], "t": l["dst"], "w": l["weight"]} for l in links],
            "categories": categories,
            "clusters": max(assign.values()) + 1 if assign else 0,
            "indexed": len(vectors),
            "model": self.backend_name,
        }

    # ---- what is missing -------------------------------------------------

    def gaps(self, workspace: str = "default") -> list[dict]:
        """Nodes with no links at all: either a stray topic or a thread you
        started and never followed up on."""
        nodes = self.store.list_nodes(workspace)
        links = self.store.links(workspace)
        linked = {l["src"] for l in links} | {l["dst"] for l in links}
        return [{"id": n["id"], "kind": n["kind"], "title": n["title"]}
                for n in nodes if n["id"] not in linked]
