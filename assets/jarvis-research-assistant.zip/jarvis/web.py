"""Local web server - open a browser, type a field, get papers. No schedule needed.

    python -m jarvis.web --install-dir E:\\Jarvis --port 80

Then just visit  http://localhost/  any time.

Uses only the standard library (http.server), so it adds no dependency beyond
`requests`, which the source clients already need.
"""

from __future__ import annotations

import argparse
import json
import logging
import signal
import socket
import sys
import threading
import webbrowser
from datetime import date, timedelta
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

from . import core, digest
from ._console import force_utf8
from .brain import KIND_META, Brain
from .cli import DEFAULT_SOURCES, PRESETS
from .llm import LLM
from .models import Paper
from .store import Store
from .ui import PAGE

log = logging.getLogger("jarvis.web")

STATE: dict = {}          # install_dir, store, brain, llm, config


# ------------------------------------------------------------------ page

# UI lives in ui.py (PAGE is imported at the top of this file).



# ------------------------------------------------------------------ api


def _serialize(p: Paper, is_new: bool = False) -> dict:
    d = p.to_dict()
    d["authors_short"] = p.author_str(3)
    d["is_new"] = is_new
    d.pop("score_parts", None)
    d.pop("external_ids", None)
    return d


def do_search(body: dict) -> dict:
    query = (body.get("query") or "").strip()
    if not query:
        raise ValueError("Empty query")

    days = int(body.get("days") or 0)
    top = max(1, min(int(body.get("top") or 20), 100))
    since = date.today() - timedelta(days=days) if days > 0 else None
    sources = body.get("sources") or DEFAULT_SOURCES

    # deadline: the web UI must not hang because one API is slow
    raw = core.gather(query, sources, 30, since,
                      deadline=float(body.get("deadline") or 45))
    uniq = core.dedupe(raw)
    kept = core.apply_filters(uniq, since, 0)

    store: Store = STATE["store"]
    unseen_keys = {p.key for p in store.filter_new(kept)}
    if body.get("only_new"):
        kept = [p for p in kept if p.key in unseen_keys]

    ranked = core.score(kept, query)[:top]
    store.mark_seen(ranked, topic=f"search:{query[:60]}")
    store.log_run(f"search:{query[:60]}", query, len(kept), len(ranked))

    return {"papers": [_serialize(p, p.key in unseen_keys) for p in ranked],
            "raw": len(raw), "unique": len(uniq)}


def do_digest(body: dict) -> dict:
    cfg = dict(STATE["config"])
    if body.get("days"):
        cfg["days"] = int(body["days"])
    store, llm = STATE["store"], STATE["llm"]

    groups: dict[str, list[dict]] = {}
    for topic in cfg["topics"]:
        name = topic.get("name") or topic["query"][:40]
        try:
            papers, _ = digest.run_topic(topic, cfg, store, llm)
            groups[name] = [_serialize(p, True) for p in papers]
        except Exception as ex:                    # noqa: BLE001
            log.error("topic %s failed: %s", name, ex)
            groups[name] = []
    return {"groups": groups}


# ------------------------------------------------------------ brain api


def _brain() -> Brain:
    return STATE["brain"]


def _ws(body: dict) -> str:
    return (body.get("ws") or "default").strip() or "default"


def do_graph(ws: str) -> dict:
    return _brain().graph(ws)


def do_node(node_id: str) -> dict:
    store: Store = STATE["store"]
    n = store.get_node(node_id)
    if not n:
        raise ValueError("node not found")
    n["color"] = KIND_META.get(n["kind"], {}).get("color", "#9aa3ad")
    return {"node": n,
            "similar": _brain().similar_to(node_id, n["workspace"], top=8)}


def do_node_save(body: dict) -> dict:
    store: Store = STATE["store"]
    nid = store.upsert_node(
        kind=(body.get("kind") or "note").strip(),
        title=(body.get("title") or "").strip(),
        body=body.get("body") or "",
        tags=body.get("tags") or "",
        url=body.get("url") or "",
        status=body.get("status") or "",
        workspace=_ws(body),
        node_id=(body.get("id") or None),
    )
    return {"id": nid}


def do_save_paper(body: dict) -> dict:
    p = body.get("paper") or {}
    if not p.get("title"):
        raise ValueError("paper has no title")
    paper = Paper(
        title=p.get("title", ""),
        abstract=p.get("abstract", "") or "",
        authors=p.get("authors") or [],
        published=Paper.parse_date(p.get("published")),
        url=p.get("url", "") or "",
        pdf_url=p.get("pdf_url", "") or "",
        doi=p.get("doi", "") or "",
        venue=p.get("venue", "") or "",
        citations=int(p.get("citations") or 0),
        source=p.get("source", "") or "",
    )
    ws = _ws(body)
    STATE["store"].ensure_workspace(ws)
    return {"id": _brain().save_paper(paper, workspace=ws,
                                      tags=body.get("tags", ""))}


# -------------------------------------------------------------- handler


class Handler(BaseHTTPRequestHandler):
    server_version = "Jarvis"

    def log_message(self, fmt, *args):             # quieter than the default
        log.info("%s %s", self.address_string(), fmt % args)

    # ---- helpers ----
    def _send(self, code: int, body: bytes, ctype: str) -> None:
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        try:
            self.wfile.write(body)
        except (BrokenPipeError, ConnectionResetError):
            pass                                    # browser tab closed mid-response

    def _json(self, obj, code: int = 200) -> None:
        self._send(code, json.dumps(obj, ensure_ascii=False).encode("utf-8"),
                   "application/json; charset=utf-8")

    def _guard(self) -> bool:
        """Serve localhost only. Reject requests from other machines on the LAN."""
        if self.client_address[0] not in ("127.0.0.1", "::1", "::ffff:127.0.0.1"):
            self._send(403, b"forbidden", "text/plain")
            return False
        return True

    # ---- routes ----
    def do_GET(self) -> None:
        if not self._guard():
            return
        u = urlparse(self.path)
        path, qs = u.path, parse_qs(u.query)

        if path in ("/", "/index.html"):
            self._send(200, PAGE.encode("utf-8"), "text/html; charset=utf-8")
        elif path == "/api/presets":
            from . import __version__
            chips = [{"label": k, "query": v["query"]} for k, v in PRESETS.items()]
            chips += [{"label": t.get("name", "")[:28], "query": t["query"]}
                      for t in STATE["config"]["topics"]]
            seen, uniq = set(), []
            for c in chips:
                if c["query"] not in seen:
                    seen.add(c["query"])
                    uniq.append(c)
            self._json({"version": __version__, "chips": uniq})
        elif path == "/api/stats":
            self._json(STATE["store"].stats())
        elif path == "/api/workspaces":
            self._json({"workspaces": STATE["store"].workspaces()})
        elif path == "/api/graph":
            self._json(do_graph(qs.get("ws", ["default"])[0]))
        elif path == "/api/node":
            nid = qs.get("id", [""])[0]
            if not nid:
                return self._json({"error": "missing id"}, 400)
            try:
                self._json(do_node(nid))
            except ValueError as e:
                self._json({"error": str(e)}, 404)
        elif path == "/healthz":
            self._send(200, b"ok", "text/plain")
        else:
            self._send(404, b"not found", "text/plain")

    def do_POST(self) -> None:
        if not self._guard():
            return
        path = urlparse(self.path).path
        try:
            n = int(self.headers.get("Content-Length") or 0)
            body = json.loads(self.rfile.read(n) or b"{}")
        except (ValueError, json.JSONDecodeError):
            return self._json({"error": "bad JSON body"}, 400)

        try:
            if path == "/api/search":
                self._json(do_search(body))
            elif path == "/api/digest":
                self._json(do_digest(body))
            elif path == "/api/node/save":
                self._json(do_node_save(body))
            elif path == "/api/node/delete":
                ok = STATE["store"].delete_node(body.get("id") or "")
                self._json({"deleted": ok})
            elif path == "/api/workspace/new":
                name = (body.get("name") or "").strip()
                if not name:
                    raise ValueError("workspace name required")
                self._json({"id": STATE["store"].ensure_workspace(name)})
            elif path == "/api/brain/refresh":
                self._json(_brain().refresh(_ws(body)))
            elif path == "/api/brain/search":
                q = (body.get("query") or "").strip()
                if not q:
                    raise ValueError("Empty query")
                self._json({"hits": _brain().search(q, _ws(body),
                                                    int(body.get("top") or 20))})
            elif path == "/api/brain/save_paper":
                self._json(do_save_paper(body))
            else:
                self._json({"error": "not found"}, 404)
        except ValueError as e:
            self._json({"error": str(e)}, 400)
        except Exception as e:                      # noqa: BLE001
            log.exception("request failed")
            self._json({"error": f"{type(e).__name__}: {e}"}, 500)


# ----------------------------------------------------------------- main


def pick_port(preferred: int, fallbacks=(8765, 8080, 8000, 0)) -> int:
    """First free port. 0 lets the OS choose."""
    for port in (preferred, *fallbacks):
        try:
            with socket.socket() as s:
                s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
                s.bind(("127.0.0.1", port))
                return s.getsockname()[1]
        except OSError:
            log.warning("port %s busy, trying next", port)
    raise SystemExit("No free port found")


def main(argv: list[str] | None = None) -> int:
    force_utf8()
    ap = argparse.ArgumentParser(description="Jarvis local web server")
    ap.add_argument("--install-dir", type=Path, default=Path("."))
    ap.add_argument("--config", type=Path, default=None)
    ap.add_argument("--port", type=int, default=80)
    ap.add_argument("--no-browser", action="store_true")
    ap.add_argument("--log-file", type=Path, default=None,
                    help="Write logs to a file. REQUIRED when launched via "
                         "pythonw.exe, which has no console to show errors.")
    ap.add_argument("-v", "--verbose", action="store_true")
    a = ap.parse_args(argv)

    handlers: list[logging.Handler] = [logging.StreamHandler()]
    if a.log_file:
        a.log_file.parent.mkdir(parents=True, exist_ok=True)
        handlers.append(logging.FileHandler(a.log_file, encoding="utf-8"))
    logging.basicConfig(level=logging.INFO if a.verbose else logging.WARNING,
                        format="  %(asctime)s [%(levelname)s] %(message)s",
                        datefmt="%H:%M:%S", handlers=handlers, force=True)

    cfg_path = a.config or (a.install_dir / "topics.json")
    cfg = digest.load_config(cfg_path if cfg_path.exists() else None)
    cfg["install_dir"] = str(a.install_dir)

    store = Store(a.install_dir / "data" / "jarvis.db")
    store.ensure_workspace("default")
    STATE.update(install_dir=a.install_dir, config=cfg, store=store,
                 brain=Brain(store, cfg.get("embed_model", "hashing")),
                 llm=LLM("auto"))

    port = pick_port(a.port)
    url = f"http://localhost{'' if port == 80 else ':' + str(port)}/"

    httpd = ThreadingHTTPServer(("127.0.0.1", port), Handler)
    httpd.daemon_threads = True

    # pid + port to file: stop_server.bat and setup.ps1 read this to find the server
    runtime = a.install_dir / "data"
    runtime.mkdir(parents=True, exist_ok=True)
    pid_file = runtime / "server.pid"
    try:
        import os
        pid_file.write_text(json.dumps({"pid": os.getpid(), "port": port, "url": url}),
                            encoding="utf-8")
    except OSError as e:
        log.warning("Could not write pid file: %s", e)

    banner = (f"\n  Jarvis is running at  {url}\n"
              f"  Install dir: {a.install_dir.resolve()}\n"
              f"  Topics: {len(cfg['topics'])} · LLM: {STATE['llm'].backend or 'off'}\n"
              f"  Press Ctrl+C to stop.\n")
    print(banner)
    log.info("server started on port %s", port)

    if not a.no_browser:
        threading.Timer(0.6, lambda: webbrowser.open(url)).start()

    # stop_server.bat uses Stop-Process -> SIGTERM. By default Python dies at
    # once, finally never runs, and a stale pid file misleads the next start.
    def _bye(signum, frame):
        raise KeyboardInterrupt
    for sig in ("SIGTERM", "SIGBREAK", "SIGINT"):
        s = getattr(signal, sig, None)
        if s is not None:
            try:
                signal.signal(s, _bye)
            except (ValueError, OSError):
                pass                       # not the main thread / unsupported OS

    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\n  Stopped.")
    finally:
        httpd.server_close()
        pid_file.unlink(missing_ok=True)
        log.info("server stopped, pid file removed")
    return 0


if __name__ == "__main__":
    sys.exit(main())
