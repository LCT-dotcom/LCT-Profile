"""Core pipeline: query sources in parallel -> dedupe -> score -> rank."""

from __future__ import annotations

import logging
import math
import re
from concurrent.futures import ThreadPoolExecutor, as_completed
from concurrent.futures import TimeoutError as FuturesTimeout
from datetime import date

from .models import Paper, merge
from .sources import REGISTRY

log = logging.getLogger("jarvis.core")

STOP = {
    "the", "a", "an", "of", "and", "or", "for", "in", "on", "with", "to", "from",
    "using", "based", "via", "by", "is", "are", "we", "this", "that", "study",
}


def tokens(text: str) -> set[str]:
    # \w + re.UNICODE so non-ASCII queries are not stripped down to nothing
    return {w for w in re.findall(r"\w+", text.lower(), re.UNICODE)
            if len(w) > 2 and w not in STOP}


# ------------------------------------------------------------- gather


def gather(query: str, sources: list[str], limit_per_source: int = 30,
           since: date | None = None, opts: dict | None = None,
           deadline: float | None = None) -> list[Paper]:
    """Query every source in parallel. One failing source never breaks the rest.

    deadline: max seconds to wait for ALL sources. Whatever has not answered by
    then is dropped and we return what did arrive. Essential for the web UI -
    one hanging API must not hang the page.
    """
    opts = opts or {}
    out: list[Paper] = []

    ex = ThreadPoolExecutor(max_workers=min(max(len(sources), 1), 8))
    try:
        futs = {}
        for name in sources:
            fn = REGISTRY.get(name)
            if not fn:
                log.warning("Skipping unknown source: %s", name)
                continue
            futs[ex.submit(fn, query, limit_per_source, since, **opts.get(name, {}))] = name

        done = set()
        try:
            for fut in as_completed(futs, timeout=deadline):
                name = futs[fut]
                done.add(name)
                try:
                    res = fut.result()
                    log.info("%-16s -> %d results", name, len(res))
                    out.extend(res)
                except Exception as e:            # noqa: BLE001
                    log.error("Source %s failed: %s", name, e)
        except FuturesTimeout:
            late = [n for n in futs.values() if n not in done]
            log.warning("Past %.0fs, dropping unresponsive sources: %s",
                        deadline or 0, ", ".join(late))
            for fut in futs:
                fut.cancel()
    finally:
        # do not wait on stuck threads; they die when their request times out
        ex.shutdown(wait=False)
    return out


# -------------------------------------------------------------- dedupe


def dedupe(papers: list[Paper]) -> list[Paper]:
    """Merge by DOI first, then by normalised title (catches preprint/journal pairs)."""
    by_key: dict[str, Paper] = {}
    for p in papers:
        if not p.title:
            continue
        k = p.key
        by_key[k] = merge(by_key[k], p) if k in by_key else p

    # pass 2: merge DOI-bearing records with title-only duplicates
    by_title: dict[str, Paper] = {}
    for p in by_key.values():
        t = p.norm_title
        if not t:
            by_title[p.key] = p
            continue
        by_title[t] = merge(by_title[t], p) if t in by_title else p
    return list(by_title.values())


# ------------------------------------------------------------- ranking


def score(papers: list[Paper], query: str, today: date | None = None,
          w_recency: float = 0.45, w_relevance: float = 0.35,
          w_impact: float = 0.20, half_life_days: float = 180.0) -> list[Paper]:
    """Score 0-1 on three axes: recency, query match, impact.

    - recency: exponential decay, 180-day half-life by default.
    - relevance: token overlap of query with title+abstract, title weighted x2.
    - impact: log(citations) normalised against the top paper in the set.
    """
    today = today or date.today()
    qt = tokens(query)
    max_log_cit = max((math.log1p(p.citations) for p in papers), default=0.0) or 1.0

    for p in papers:
        recency = 0.5 ** (p.age_days(today) / half_life_days)

        if qt:
            tt, at = tokens(p.title), tokens(p.abstract)
            hit = len(qt & tt) * 2 + len(qt & at)
            relevance = min(hit / (len(qt) * 2.0), 1.0)
        else:
            relevance = 0.5

        impact = math.log1p(p.citations) / max_log_cit

        # small bonus when several sources carry it - a sign it actually landed
        multi = 0.05 * (p.source.count("+"))

        p.score_parts = {"recency": round(recency, 4),
                         "relevance": round(relevance, 4),
                         "impact": round(impact, 4),
                         "multi_source": round(multi, 4)}
        p.score = round(min(
            w_recency * recency + w_relevance * relevance + w_impact * impact + multi,
            1.0), 4)

    papers.sort(key=lambda x: (x.score, x.published or date.min), reverse=True)
    return papers


# --------------------------------------------------------------- filter


def apply_filters(papers: list[Paper], since: date | None = None,
                  min_citations: int = 0, require_abstract: bool = True,
                  exclude_terms: list[str] | None = None) -> list[Paper]:
    ex = [t.lower() for t in (exclude_terms or [])]
    out = []
    for p in papers:
        if require_abstract and len(p.abstract) < 80:
            continue
        if since and p.published and p.published < since:
            continue
        if p.citations < min_citations:
            continue
        blob = (p.title + " " + p.abstract).lower()
        if any(t in blob for t in ex):
            continue
        out.append(p)
    return out


# ------------------------------------------------------------ pipeline


def search(query: str, sources: list[str], limit_per_source: int = 30,
           since: date | None = None, top_k: int = 20,
           min_citations: int = 0, exclude_terms: list[str] | None = None,
           opts: dict | None = None) -> list[Paper]:
    raw = gather(query, sources, limit_per_source, since, opts)
    log.info("Raw total: %d", len(raw))
    uniq = dedupe(raw)
    log.info("After dedupe: %d", len(uniq))
    kept = apply_filters(uniq, since, min_citations, exclude_terms=exclude_terms)
    log.info("After filtering: %d", len(kept))
    ranked = score(kept, query)
    return ranked[:top_k]
