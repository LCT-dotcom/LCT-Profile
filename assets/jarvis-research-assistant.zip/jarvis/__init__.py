"""Jarvis - research paper scanner for medicine, signal processing and vision."""

__version__ = "2.0.1"

# Must run BEFORE any print/log. The Windows console defaults to cp1252/cp1258,
# where printing non-ASCII raises UnicodeEncodeError and kills the script.
from ._console import force_utf8   # noqa: E402

force_utf8()

from .models import Paper          # noqa: E402,F401
from .core import search           # noqa: E402,F401
